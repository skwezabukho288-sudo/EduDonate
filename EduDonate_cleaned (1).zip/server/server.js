
"use strict";

const express = require("express");
const cors = require("cors");
const path = require("path");
require("dotenv").config();

const { connectDatabase } = require("./config/db");

const authRoutes = require("./routes/auth");
const donationRoutes = require("./routes/donations");
const requestRoutes = require("./routes/requests");
const distributionRoutes = require("./routes/distributions");

const app = express();
const PORT = process.env.PORT || 3000;

// Project root: EduDonate/
const projectRoot = path.resolve(__dirname, "..");
const pagesDirectory = path.join(projectRoot, "pages");

app.use(
    cors({
        origin: process.env.CLIENT_URL || true,
        credentials: true
    })
);

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve files from EduDonate/pages/
app.use("/pages", express.static(pagesDirectory));

// Serve other project-level static files when requested.
app.use(express.static(projectRoot));

// Health check
app.get("/api/health", (req, res) => {
    res.json({
        success: true,
        message: "EduDonate API is running"
    });
});

// API routes
app.use("/api/auth", authRoutes);
app.use("/api/donations", donationRoutes);
app.use("/api/requests", requestRoutes);
app.use("/api/distributions", distributionRoutes);

// Root page redirects to the login page.
app.get("/", (req, res) => {
    res.redirect("/pages/login.html");
});

// Handle requests for missing pages.
app.use((req, res) => {
    res.status(404).send(
        "Page not found. Check the URL and make sure the file exists."
    );
});

async function startServer() {
    try {
        await connectDatabase();

        app.listen(PORT, () => {
            console.log("=================================");
            console.log("       EDUDONATE APPLICATION");
            console.log("=================================");
            console.log(`Server: http://localhost:${PORT}`);
            console.log(`Home: http://localhost:${PORT}/`);
            console.log(
                `Login: http://localhost:${PORT}/pages/login.html`
            );
            console.log(
                `Health: http://localhost:${PORT}/api/health`
            );
            console.log("=================================");
        });
    } catch (error) {
        console.error("Unable to start EduDonate.");
        console.error(error);
        process.exit(1);
    }
}

startServer();
