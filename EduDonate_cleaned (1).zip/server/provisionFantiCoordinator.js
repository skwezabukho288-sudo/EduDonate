"use strict";

const sql = require("msnodesqlv8");
const bcrypt = require("bcryptjs");
const readline = require("readline/promises");
const { stdin, stdout } = require("process");
const { connectionString } = require("./config/db");

const SCHOOL_ID = 3;

const coordinator = {
    firstName: "Fanti",
    lastName: "Coordinator",
    email: "fanti_coord01@example.com",
    username: "fanti_coord01",
    phone: "0710000303",
    gender: null,
    staffNumber: "FANTI01",
    role: "COORDINATOR"
};

async function provisionCoordinator() {
    let connection = null;
    let transactionStarted = false;

    const terminal = readline.createInterface({
        input: stdin,
        output: stdout
    });

    try {
        const password = await terminal.question(
            "Enter the test password for fanti_coord01: "
        );

        if (password.length < 8) {
            throw new Error(
                "Password must contain at least 8 characters."
            );
        }

        connection = await sql.promises.open(connectionString);

        await connection.promises.beginTransaction();
        transactionStarted = true;

        // 1. Confirm that the school exists.
        const schoolResult = await connection.promises.query(
            `SELECT SCHOOLID
             FROM dbo.SCHOOLS
             WHERE SCHOOLID = ?`,
            [SCHOOL_ID]
        );

        if (!schoolResult.first?.length) {
            throw new Error(
                `School ID ${SCHOOL_ID} does not exist.`
            );
        }

        // 2. Check for an existing username or email.
        const existingAccount = await connection.promises.query(
            `SELECT TOP 1 PERSONID
             FROM dbo.PERSONS
             WHERE LOWER(USERNAME) = ?
                OR LOWER(EMAIL) = ?`,
            [
                coordinator.username.toLowerCase(),
                coordinator.email.toLowerCase()
            ]
        );

        if (existingAccount.first?.length) {
            throw new Error(
                "This username or email already exists. " +
                "Choose a different test account."
            );
        }

        // 3. Check whether this school already has an active coordinator.
        const existingCoordinator =
            await connection.promises.query(
                `SELECT TOP 1 DCID
                 FROM dbo.DONATION_COORDINATORS
                 WHERE SCHOOLID = ?
                   AND STATUS = 'ACTIVE'`,
                [SCHOOL_ID]
            );

        if (existingCoordinator.first?.length) {
            throw new Error(
                `School ID ${SCHOOL_ID} already has an active ` +
                "coordinator. No new account was created."
            );
        }

        // 4. Check that the staff number is not already in use.
        const existingStaff = await connection.promises.query(
            `SELECT TOP 1 DCID
             FROM dbo.DONATION_COORDINATORS
             WHERE STAFF_NO = ?`,
            [coordinator.staffNumber]
        );

        if (existingStaff.first?.length) {
            throw new Error(
                "The staff number is already in use."
            );
        }

        // 5. Hash the password before saving it.
        const passwordHash = await bcrypt.hash(password, 12);

        // 6. Insert the person's details.
        const personResult = await connection.promises.query(
            `INSERT INTO dbo.PERSONS
                (
                    FIRSTNAME,
                    LASTNAME,
                    EMAIL,
                    USERNAME,
                    PHONENO,
                    GENDER
                )
             OUTPUT INSERTED.PERSONID AS PERSONID
             VALUES (?, ?, ?, ?, ?, ?)`,
            [
                coordinator.firstName,
                coordinator.lastName,
                coordinator.email,
                coordinator.username,
                coordinator.phone,
                coordinator.gender
            ]
        );

        const personId = personResult.first?.[0]?.PERSONID;

        if (!personId) {
            throw new Error(
                "Could not retrieve the new person's ID."
            );
        }

        // 7. Create the login account.
        const userResult = await connection.promises.query(
            `INSERT INTO dbo.USERS
                (
                    PERSONID,
                    PASSWORD_HASH,
                    ROLE,
                    IS_ACTIVE
                )
             OUTPUT INSERTED.USERID AS USERID
             VALUES (?, ?, ?, 1)`,
            [
                personId,
                passwordHash,
                coordinator.role
            ]
        );

        const userId = userResult.first?.[0]?.USERID;

        if (!userId) {
            throw new Error(
                "Could not retrieve the new user's ID."
            );
        }

        // 8. Link the coordinator to the school.
        const coordinatorResult =
            await connection.promises.query(
                `INSERT INTO dbo.DONATION_COORDINATORS
                    (
                        PERSONID,
                        STAFF_NO,
                        SCHOOLID,
                        STATUS
                    )
                 OUTPUT INSERTED.DCID AS DCID
                 VALUES (?, ?, ?, 'ACTIVE')`,
                [
                    personId,
                    coordinator.staffNumber,
                    SCHOOL_ID
                ]
            );

        const coordinatorId =
            coordinatorResult.first?.[0]?.DCID;

        if (!coordinatorId) {
            throw new Error(
                "Could not retrieve the coordinator's ID."
            );
        }

        // 9. Save all three records together.
        await connection.promises.commit();
        transactionStarted = false;

        console.log("\nCoordinator created successfully!");
        console.log("--------------------------------");
        console.log("Username:", coordinator.username);
        console.log("Role:", coordinator.role);
        console.log("School ID:", SCHOOL_ID);
        console.log("Person ID:", personId);
        console.log("User ID:", userId);
        console.log("Coordinator ID:", coordinatorId);
        console.log("Staff number:", coordinator.staffNumber);
        console.log("--------------------------------");

    } catch (error) {
        if (connection && transactionStarted) {
            try {
                await connection.promises.rollback();
            } catch (rollbackError) {
                console.error(
                    "Rollback failed:",
                    rollbackError.message
                );
            }
        }

        console.error("\nCoordinator creation failed:");
        console.error(error.message);

        process.exitCode = 1;

    } finally {
        terminal.close();

        if (connection) {
            try {
                await connection.promises.close();
            } catch (closeError) {
                console.error(
                    "Database connection close failed:",
                    closeError.message
                );
            }
        }
    }
}

provisionCoordinator();