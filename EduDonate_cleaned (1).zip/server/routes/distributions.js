const express = require("express");
const sql = require("msnodesqlv8");

const { connectionString } = require("../config/db");
const {
    authenticateToken,
    requireRole
} = require("../middleware/authMiddleware");

const router = express.Router();

class RouteError extends Error {
    constructor(message, statusCode = 400) {
        super(message);
        this.name = "RouteError";
        this.statusCode = statusCode;
    }
}

async function openDatabaseConnection() {
    return sql.promises.open(connectionString);
}

function getRows(result) {
    return result && Array.isArray(result.first)
        ? result.first
        : [];
}

function getFirstRow(result) {
    return getRows(result)[0] || null;
}

function getRole(req) {
    return String(req.user?.role || "").trim().toUpperCase();
}

async function getActiveCoordinator(connection, personId) {
    const result = await connection.promises.query(
        `
        SELECT TOP 1
            DCID,
            PERSONID,
            SCHOOLID,
            STATUS
        FROM dbo.DONATION_COORDINATORS
        WHERE PERSONID = ?
        `,
        [personId]
    );

    const coordinator = getFirstRow(result);

    if (!coordinator) {
        throw new RouteError(
            "Coordinator profile could not be found.",
            403
        );
    }

    if (String(coordinator.STATUS || "").toUpperCase() !== "ACTIVE") {
        throw new RouteError(
            "Your coordinator account is inactive.",
            403
        );
    }

    return coordinator;
}

function distributionSelectSql(whereClause = "") {
    return `
        SELECT
            D.DISTRIBUTIONID,
            D.REQUESTID,
            D.DONATIONID,
            D.CURRENTID,
            D.DCID,
            D.QUANTITY,
            D.DISTRIBUTIONDATE,
            D.CONFIRMATION,
            D.COMMENTS,
            P.FIRSTNAME AS LEARNER_FIRSTNAME,
            P.LASTNAME AS LEARNER_LASTNAME,
            LTRIM(RTRIM(CONCAT(
                COALESCE(P.FIRSTNAME, ''),
                ' ',
                COALESCE(P.LASTNAME, '')
            ))) AS LEARNER_NAME,
            S.SCHOOLNAME
        FROM dbo.DISTRIBUTIONS AS D
        INNER JOIN dbo.ITEMDONATIONS AS DON
            ON D.DONATIONID = DON.DONATIONID
        LEFT JOIN dbo.CURRENT_LEARNERS AS C
            ON D.CURRENTID = C.CURRENTID
        LEFT JOIN dbo.LEARNERS AS L
            ON C.LEARNERID = L.LEARNERID
        LEFT JOIN dbo.PERSONS AS P
            ON L.PERSONID = P.PERSONID
        LEFT JOIN dbo.SCHOOLS AS S
            ON DON.SCHOOLID = S.SCHOOLID
        ${whereClause}
        ORDER BY D.DISTRIBUTIONID DESC
    `;
}

/* =====================================================
   GET /api/distributions

   Admins can view all distribution records.
   Coordinators can view records for their own school.
===================================================== */

router.get(
    "/",
    authenticateToken,
    requireRole("ADMIN", "COORDINATOR"),
    async (req, res) => {
        let connection;

        try {
            connection = await openDatabaseConnection();

            const role = getRole(req);

            if (role === "ADMIN") {
                const result = await connection.promises.query(
                    distributionSelectSql()
                );

                return res.status(200).json({
                    success: true,
                    distributions: getRows(result)
                });
            }

            const coordinator = await getActiveCoordinator(
                connection,
                req.user.personId
            );

            const result = await connection.promises.query(
                distributionSelectSql("WHERE DON.SCHOOLID = ?"),
                [coordinator.SCHOOLID]
            );

            return res.status(200).json({
                success: true,
                distributions: getRows(result)
            });
        } catch (error) {
            console.error("GET DISTRIBUTIONS ERROR:", error);

            return res.status(error.statusCode || 500).json({
                success: false,
                message: error.statusCode
                    ? error.message
                    : "Unable to retrieve distributions."
            });
        } finally {
            if (connection) {
                try {
                    await connection.promises.close();
                } catch (closeError) {
                    console.error(
                        "DATABASE CLOSE ERROR:",
                        closeError
                    );
                }
            }
        }
    }
);

/* =====================================================
   POST /api/distributions

   Only an active coordinator can record a distribution.

   Expected body:
   {
       requestId,
       donationId,
       quantity,
       comments
   }
===================================================== */

router.post(
    "/",
    authenticateToken,
    requireRole("COORDINATOR"),
    async (req, res) => {
        let connection;
        let transactionStarted = false;

        try {
            const requestId = Number(req.body?.requestId);
            const donationId = Number(req.body?.donationId);
            const quantity = Number(req.body?.quantity);

            const comments = req.body?.comments == null
                ? null
                : String(req.body.comments).trim();

            if (!Number.isSafeInteger(requestId) || requestId <= 0) {
                throw new RouteError("Invalid request ID.");
            }

            if (!Number.isSafeInteger(donationId) || donationId <= 0) {
                throw new RouteError("Invalid donation ID.");
            }

            if (!Number.isSafeInteger(quantity) || quantity <= 0) {
                throw new RouteError(
                    "Distribution quantity must be a whole number greater than zero."
                );
            }

            if (comments !== null && comments.length > 500) {
                throw new RouteError(
                    "Comments cannot exceed 500 characters."
                );
            }

            connection = await openDatabaseConnection();

            await connection.promises.beginTransaction();
            transactionStarted = true;

            const coordinator = await getActiveCoordinator(
                connection,
                req.user.personId
            );

            /* ==========================================
               FIND REQUEST
            ========================================== */

            const requestResult = await connection.promises.query(
                `
                SELECT TOP 1
                    REQUESTID,
                    STATUS,
                    CURRENTID,
                    SCHOOLID,
                    QUANTITY,
                    CAID,
                    ITSID
                FROM dbo.ITEMREQUESTS
                WHERE REQUESTID = ?
                `,
                [requestId]
            );

            const request = getFirstRow(requestResult);

            if (!request) {
                throw new RouteError(
                    "Learner request could not be found.",
                    404
                );
            }

            if (String(request.STATUS || "").toUpperCase() !== "APPROVED") {
                throw new RouteError(
                    "Only approved requests can be distributed."
                );
            }

            if (
                Number(request.SCHOOLID) !==
                Number(coordinator.SCHOOLID)
            ) {
                throw new RouteError(
                    "You cannot distribute a request from another school.",
                    403
                );
            }

            /* ==========================================
               FIND DONATION
            ========================================== */

            const donationResult = await connection.promises.query(
                `
                SELECT TOP 1
                    DONATIONID,
                    FORMERID,
                    SCHOOLID,
                    QUANTITY,
                    CONFIRMATION,
                    CAID,
                    ITSID
                FROM dbo.ITEMDONATIONS
                WHERE DONATIONID = ?
                `,
                [donationId]
            );

            const donation = getFirstRow(donationResult);

            if (!donation) {
                throw new RouteError(
                    "Donation could not be found.",
                    404
                );
            }

            const donationStatus = String(
                donation.CONFIRMATION || ""
            ).toUpperCase();

            if (!["RECEIVED", "PARTIAL"].includes(donationStatus)) {
                throw new RouteError(
                    "Only received donations with available stock can be distributed."
                );
            }

            if (
                Number(donation.SCHOOLID) !==
                Number(coordinator.SCHOOLID)
            ) {
                throw new RouteError(
                    "You cannot distribute a donation from another school.",
                    403
                );
            }

            /* ==========================================
               MATCH CATEGORY AND SIZE
            ========================================== */

            if (Number(donation.CAID) !== Number(request.CAID)) {
                throw new RouteError(
                    "The donation category does not match the learner request."
                );
            }

            if (Number(donation.ITSID) !== Number(request.ITSID)) {
                throw new RouteError(
                    "The donation size does not match the learner request."
                );
            }

            /* ==========================================
               CALCULATE DONATION REMAINING QUANTITY
            ========================================== */

            const distributedDonationResult =
                await connection.promises.query(
                    `
                    SELECT
                        COALESCE(SUM(QUANTITY), 0)
                            AS DISTRIBUTED_QUANTITY
                    FROM dbo.DISTRIBUTIONS
                    WHERE DONATIONID = ?
                      AND CONFIRMATION = 'DISTRIBUTED'
                    `,
                    [donationId]
                );

            const donationAlreadyDistributed = Number(
                getFirstRow(distributedDonationResult)
                    ?.DISTRIBUTED_QUANTITY || 0
            );

            const donationRemaining =
                Number(donation.QUANTITY) -
                donationAlreadyDistributed;

            /* ==========================================
               CALCULATE REQUEST REMAINING QUANTITY
            ========================================== */

            const distributedRequestResult =
                await connection.promises.query(
                    `
                    SELECT
                        COALESCE(SUM(QUANTITY), 0)
                            AS DISTRIBUTED_QUANTITY
                    FROM dbo.DISTRIBUTIONS
                    WHERE REQUESTID = ?
                      AND CONFIRMATION = 'DISTRIBUTED'
                    `,
                    [requestId]
                );

            const requestAlreadyDistributed = Number(
                getFirstRow(distributedRequestResult)
                    ?.DISTRIBUTED_QUANTITY || 0
            );

            const requestRemaining =
                Number(request.QUANTITY) -
                requestAlreadyDistributed;

            /* ==========================================
               VALIDATE QUANTITIES
            ========================================== */

            if (donationRemaining <= 0) {
                throw new RouteError(
                    "This donation has no quantity remaining."
                );
            }

            if (requestRemaining <= 0) {
                throw new RouteError(
                    "This learner request has already been fulfilled."
                );
            }

            if (quantity > donationRemaining) {
                throw new RouteError(
                    `Only ${donationRemaining} item(s) remain from this donation.`
                );
            }

            if (quantity > requestRemaining) {
                throw new RouteError(
                    `The learner still needs only ${requestRemaining} item(s).`
                );
            }

            /* ==========================================
               VERIFY CURRENT LEARNER
            ========================================== */

            const currentLearnerResult =
                await connection.promises.query(
                    `
                    SELECT TOP 1 CURRENTID
                    FROM dbo.CURRENT_LEARNERS
                    WHERE CURRENTID = ?
                    `,
                    [request.CURRENTID]
                );

            if (!getFirstRow(currentLearnerResult)) {
                throw new RouteError(
                    "Current learner profile could not be found.",
                    404
                );
            }

            /* ==========================================
               CREATE DISTRIBUTION RECORD
            ========================================== */

            const distributionResult =
                await connection.promises.query(
                    `
                    INSERT INTO dbo.DISTRIBUTIONS
                    (
                        REQUESTID,
                        DONATIONID,
                        CURRENTID,
                        DCID,
                        QUANTITY,
                        CONFIRMATION,
                        COMMENTS
                    )
                    OUTPUT
                        INSERTED.DISTRIBUTIONID,
                        INSERTED.REQUESTID,
                        INSERTED.DONATIONID,
                        INSERTED.CURRENTID,
                        INSERTED.DCID,
                        INSERTED.QUANTITY,
                        INSERTED.DISTRIBUTIONDATE,
                        INSERTED.CONFIRMATION,
                        INSERTED.COMMENTS
                    VALUES (?, ?, ?, ?, ?, 'DISTRIBUTED', ?)
                    `,
                    [
                        requestId,
                        donationId,
                        request.CURRENTID,
                        coordinator.DCID,
                        quantity,
                        comments
                    ]
                );

            const distribution = getFirstRow(distributionResult);

            if (!distribution) {
                throw new Error(
                    "The distribution record was not returned after insertion."
                );
            }

            /* ==========================================
               UPDATE REQUEST STATUS
            ========================================== */

            const requestRemainingAfter =
                requestRemaining - quantity;

            if (requestRemainingAfter === 0) {
                await connection.promises.query(
                    `
                    UPDATE dbo.ITEMREQUESTS
                    SET STATUS = 'COLLECTED'
                    WHERE REQUESTID = ?
                    `,
                    [requestId]
                );
            }

            /* ==========================================
               UPDATE DONATION STATUS
            ========================================== */

            const donationRemainingAfter =
                donationRemaining - quantity;

            await connection.promises.query(
                `
                UPDATE dbo.ITEMDONATIONS
                SET CONFIRMATION = ?
                WHERE DONATIONID = ?
                `,
                [
                    donationRemainingAfter === 0
                        ? "COMPLETED"
                        : "PARTIAL",
                    donationId
                ]
            );

            /* ==========================================
               COMMIT TRANSACTION
            ========================================== */

            await connection.promises.commit();
            transactionStarted = false;

            return res.status(201).json({
                success: true,
                message: "Distribution recorded successfully.",
                distribution,
                remainingDonationQuantity: donationRemainingAfter,
                remainingRequestQuantity: requestRemainingAfter
            });

        } catch (error) {
            if (connection && transactionStarted) {
                try {
                    await connection.promises.rollback();
                } catch (rollbackError) {
                    console.error(
                        "DISTRIBUTION ROLLBACK ERROR:",
                        rollbackError
                    );
                }
            }

            console.error("CREATE DISTRIBUTION ERROR:", error);

            return res.status(error.statusCode || 500).json({
                success: false,
                message: error.statusCode
                    ? error.message
                    : "Unable to create distribution. Please check the server logs."
            });

        } finally {
            if (connection) {
                try {
                    await connection.promises.close();
                } catch (closeError) {
                    console.error(
                        "DATABASE CLOSE ERROR:",
                        closeError
                    );
                }
            }
        }
    }
);

module.exports = router;