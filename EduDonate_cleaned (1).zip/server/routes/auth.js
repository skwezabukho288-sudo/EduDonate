"use strict";

const express = require("express");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const sql = require("msnodesqlv8");

const { connectionString } = require("../config/db");
const { authenticateToken } = require("../middleware/authMiddleware");

const router = express.Router();

/* =========================================
   DATABASE CONNECTION
========================================= */

async function openDatabaseConnection() {
    return sql.promises.open(connectionString);
}

function cleanText(value) {
    return value == null ? "" : String(value).trim();
}

function getFirstRow(result) {
    return result &&
        Array.isArray(result.first) &&
        result.first.length > 0
        ? result.first[0]
        : null;
}

function isValidDateOnly(value) {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) {
        return false;
    }

    const [year, month, day] = value.split("-").map(Number);
    const date = new Date(Date.UTC(year, month - 1, day));

    return (
        date.getUTCFullYear() === year &&
        date.getUTCMonth() === month - 1 &&
        date.getUTCDate() === day
    );
}

function getLocalTodayDate() {
    const today = new Date();
    const year = today.getFullYear();
    const month = String(today.getMonth() + 1).padStart(2, "0");
    const day = String(today.getDate()).padStart(2, "0");

    return `${year}-${month}-${day}`;
}

/* =========================================
   REGISTER
   POST /api/auth/register

   Public roles:
   LEARNER and FORMER_LEARNER
========================================= */

router.post("/register", async (req, res) => {
    let connection = null;
    let transactionStarted = false;

    try {
        const {
            firstName,
            lastName,
            email,
            phone,
            username,
            gender,
            password,
            role,
            grade,
            leaveDate
        } = req.body || {};

        if (
            !firstName ||
            !lastName ||
            !email ||
            !phone ||
            !username ||
            !password ||
            !role
        ) {
            return res.status(400).json({
                success: false,
                message: "Please complete all required fields."
            });
        }

        const cleanFirstName = cleanText(firstName);
        const cleanLastName = cleanText(lastName);
        const cleanEmail = cleanText(email).toLowerCase();
        const cleanPhone = cleanText(phone);
        const cleanUsername = cleanText(username);
        const cleanGender = cleanText(gender) || null;
        const cleanRole = cleanText(role).toUpperCase();
        const cleanPassword = String(password);
        const cleanGrade = cleanText(grade).padStart(2, "0");
        const cleanLeaveDate = cleanText(leaveDate);

        if (
            cleanFirstName.length < 2 ||
            cleanLastName.length < 2
        ) {
            return res.status(400).json({
                success: false,
                message:
                    "First name and last name must contain at least 2 characters."
            });
        }

        const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

        if (!emailPattern.test(cleanEmail)) {
            return res.status(400).json({
                success: false,
                message: "Please enter a valid email address."
            });
        }

        if (cleanPassword.length < 8) {
            return res.status(400).json({
                success: false,
                message: "Password must contain at least 8 characters."
            });
        }

        if (cleanUsername.length < 3) {
            return res.status(400).json({
                success: false,
                message: "Username must contain at least 3 characters."
            });
        }

        const allowedRoles = ["LEARNER", "FORMER_LEARNER"];

        if (!allowedRoles.includes(cleanRole)) {
            return res.status(403).json({
                success: false,
                message:
                    "This role cannot be created through public registration."
            });
        }

        // Validate a current learner's grade.
        if (
            cleanRole === "LEARNER" &&
            !/^(0[1-9]|1[0-2])$/.test(cleanGrade)
        ) {
            return res.status(400).json({
                success: false,
                message:
                    "Please select a valid current grade from Grade 1 to Grade 12."
            });
        }

        // Former learners must have completed Grade 7 or Grade 12.
        if (cleanRole === "FORMER_LEARNER") {
        if (!/^(04|05|06|07|08|09|10)$/.test(cleanGrade)) {
    return res.status(400).json({
        success: false,
        message:
            "Former learners must select a completed grade from Grade 4 to Grade 10."
    });
}

            if (!isValidDateOnly(cleanLeaveDate)) {
                return res.status(400).json({
                    success: false,
                    message: "Please enter a valid date you left school."
                });
            }

            if (cleanLeaveDate > getLocalTodayDate()) {
                return res.status(400).json({
                    success: false,
                    message:
                        "The date you left school cannot be in the future."
                });
            }
        }

        connection = await openDatabaseConnection();

        await connection.promises.beginTransaction();
        transactionStarted = true;

        // Check whether the email already exists.
        const emailResult = await connection.promises.query(
            `
            SELECT TOP 1 PERSONID
            FROM dbo.PERSONS
            WHERE LOWER(EMAIL) = ?
            `,
            [cleanEmail]
        );

        if (emailResult.first && emailResult.first.length > 0) {
            await connection.promises.rollback();
            transactionStarted = false;

            return res.status(409).json({
                success: false,
                message: "Email address is already registered."
            });
        }

        // Check whether the username already exists.
        const usernameResult = await connection.promises.query(
            `
            SELECT TOP 1 PERSONID
            FROM dbo.PERSONS
            WHERE LOWER(USERNAME) = ?
            `,
            [cleanUsername.toLowerCase()]
        );

        if (
            usernameResult.first &&
            usernameResult.first.length > 0
        ) {
            await connection.promises.rollback();
            transactionStarted = false;

            return res.status(409).json({
                success: false,
                message: "Username is already registered."
            });
        }

        // Hash the password.
        const passwordHash = await bcrypt.hash(cleanPassword, 12);

        // Create the person's record.
        const personResult = await connection.promises.query(
            `
            INSERT INTO dbo.PERSONS
            (
                FIRSTNAME,
                LASTNAME,
                EMAIL,
                USERNAME,
                PHONENO,
                GENDER
            )
            OUTPUT INSERTED.PERSONID AS PERSONID
            VALUES (?, ?, ?, ?, ?, ?)
            `,
            [
                cleanFirstName,
                cleanLastName,
                cleanEmail,
                cleanUsername,
                cleanPhone,
                cleanGender
            ]
        );

        const person = getFirstRow(personResult);

        if (!person) {
            throw new Error("PERSONS record could not be created.");
        }

        // Create the login account.
        const userResult = await connection.promises.query(
            `
            INSERT INTO dbo.USERS
            (
                PERSONID,
                PASSWORD_HASH,
                ROLE,
                IS_ACTIVE
            )
            OUTPUT INSERTED.USERID AS USERID
            VALUES (?, ?, ?, 1)
            `,
            [
                person.PERSONID,
                passwordHash,
                cleanRole
            ]
        );

        const account = getFirstRow(userResult);

        if (!account) {
            throw new Error("USERS record could not be created.");
        }

        /*
         * Create the shared learner record.
         *
         * SCHOOLID is set to NULL because the current registration
         * form does not ask the user to choose a school. If SCHOOLID
         * is NOT NULL in your database, this insert will need to be
         * adapted to your actual school-assignment rules.
         */
        const learnerResult = await connection.promises.query(
            `
            INSERT INTO dbo.LEARNERS
            (
                PERSONID,
                GRADE,
                SCHOOLID
            )
            OUTPUT INSERTED.LEARNERID AS LEARNERID
            VALUES (?, ?, NULL)
            `,
            [
                person.PERSONID,
                cleanGrade
            ]
        );

        const learner = getFirstRow(learnerResult);

        if (!learner) {
            throw new Error("LEARNERS record could not be created.");
        }

        let currentLearnerId = null;
        let formerLearnerId = null;

        if (cleanRole === "LEARNER") {
            // Create the current learner's record.
            const currentLearnerResult =
                await connection.promises.query(
                    `
                    INSERT INTO dbo.CURRENT_LEARNERS
                    (
                        LEARNERID,
                        ENROLDATE
                    )
                    OUTPUT INSERTED.CURRENTID AS CURRENTID
                    VALUES (?, CONVERT(VARCHAR(10), GETDATE(), 23))
                    `,
                    [learner.LEARNERID]
                );

            const currentLearner = getFirstRow(
                currentLearnerResult
            );

            if (!currentLearner) {
                throw new Error(
                    "CURRENT_LEARNERS record could not be created."
                );
            }

            currentLearnerId = currentLearner.CURRENTID;
        } else {
            // Create the former learner's record.
            const formerLearnerResult =
                await connection.promises.query(
                    `
                    INSERT INTO dbo.FORMER_LEARNERS
                    (
                        LEARNERID,
                        LEAVEDATE,
                        LEAVEGRADE
                    )
                    OUTPUT INSERTED.FORMERID AS FORMERID
                    VALUES (?, ?, ?)
                    `,
                    [
                        learner.LEARNERID,
                        cleanLeaveDate,
                        cleanGrade
                    ]
                );

            const formerLearner = getFirstRow(
                formerLearnerResult
            );

            if (!formerLearner) {
                throw new Error(
                    "FORMER_LEARNERS record could not be created."
                );
            }

            formerLearnerId = formerLearner.FORMERID;
        }

        // Save the account and associated learner records.
        await connection.promises.commit();
        transactionStarted = false;

        return res.status(201).json({
            success: true,
            message: "Registration successful.",
            user: {
                userId: account.USERID,
                personId: person.PERSONID,
                role: cleanRole,
                firstName: cleanFirstName,
                lastName: cleanLastName,
                email: cleanEmail,
                username: cleanUsername,
                phone: cleanPhone,
                gender: cleanGender,
                learnerId: learner.LEARNERID,
                grade: cleanGrade,
                currentId: currentLearnerId,
                formerId: formerLearnerId,
                leaveGrade:
                    cleanRole === "FORMER_LEARNER"
                        ? cleanGrade
                        : null,
                leaveDate:
                    cleanRole === "FORMER_LEARNER"
                        ? cleanLeaveDate
                        : null
            }
        });
    } catch (error) {
        console.error("REGISTRATION ERROR:", error);

        if (connection && transactionStarted) {
            try {
                await connection.promises.rollback();
            } catch (rollbackError) {
                console.error("ROLLBACK ERROR:", rollbackError);
            }
        }

        return res.status(500).json({
            success: false,
            message: "Registration failed. Please try again."
        });
    } finally {
        if (connection) {
            try {
                await connection.promises.close();
            } catch (closeError) {
                console.error("DATABASE CLOSE ERROR:", closeError);
            }
        }
    }
});

/* =========================================
   LOGIN
   POST /api/auth/login
========================================= */

router.post("/login", async (req, res) => {
    let connection = null;

    try {
        const { username, password } = req.body || {};

        if (!username || !password) {
            return res.status(400).json({
                success: false,
                message: "Username/email and password are required."
            });
        }

        if (!process.env.JWT_SECRET) {
            console.error("JWT_SECRET is not configured.");

            return res.status(500).json({
                success: false,
                message:
                    "Authentication server configuration is incomplete."
            });
        }

        const loginValue = cleanText(username).toLowerCase();

        connection = await openDatabaseConnection();

        const result = await connection.promises.query(
            `
            SELECT TOP 1
                U.USERID,
                U.PERSONID,
                U.PASSWORD_HASH,
                U.ROLE,
                U.IS_ACTIVE,
                P.FIRSTNAME,
                P.LASTNAME,
                P.EMAIL,
                P.USERNAME,
                P.PHONENO,
                P.GENDER
            FROM dbo.USERS AS U
            INNER JOIN dbo.PERSONS AS P
                ON P.PERSONID = U.PERSONID
            WHERE
                LOWER(P.USERNAME) = ?
                OR LOWER(P.EMAIL) = ?
            `,
            [
                loginValue,
                loginValue
            ]
        );

        const user = getFirstRow(result);

        if (!user) {
            return res.status(401).json({
                success: false,
                message: "Invalid username/email or password."
            });
        }

        if (!user.IS_ACTIVE) {
            return res.status(403).json({
                success: false,
                message:
                    "Your account is inactive. Please contact an administrator."
            });
        }

        const passwordMatches = await bcrypt.compare(
            String(password),
            user.PASSWORD_HASH
        );

        if (!passwordMatches) {
            return res.status(401).json({
                success: false,
                message: "Invalid username/email or password."
            });
        }

        await connection.promises.query(
            `
            UPDATE dbo.USERS
            SET LAST_LOGIN = SYSDATETIME()
            WHERE USERID = ?
            `,
            [user.USERID]
        );

        const token = jwt.sign(
            {
                userId: user.USERID,
                personId: user.PERSONID,
                role: user.ROLE
            },
            process.env.JWT_SECRET,
            {
                expiresIn: "2h"
            }
        );

        return res.status(200).json({
            success: true,
            message: "Login successful.",
            token,
            user: {
                userId: user.USERID,
                personId: user.PERSONID,
                firstName: user.FIRSTNAME,
                lastName: user.LASTNAME,
                email: user.EMAIL,
                username: user.USERNAME,
                phone: user.PHONENO,
                gender: user.GENDER,
                role: user.ROLE,
                isActive: Boolean(user.IS_ACTIVE)
            }
        });
    } catch (error) {
        console.error("LOGIN ERROR:", error);

        return res.status(500).json({
            success: false,
            message: "Login failed. Please try again."
        });
    } finally {
        if (connection) {
            try {
                await connection.promises.close();
            } catch (closeError) {
                console.error("DATABASE CLOSE ERROR:", closeError);
            }
        }
    }
});

/* =========================================
   CURRENT USER PROFILE
   GET /api/auth/me
========================================= */

router.get("/me", authenticateToken, async (req, res) => {
    let connection = null;

    try {
        connection = await openDatabaseConnection();

        const result = await connection.promises.query(
            `
            SELECT TOP 1
                U.USERID,
                U.PERSONID,
                U.ROLE,
                U.IS_ACTIVE,
                P.FIRSTNAME,
                P.LASTNAME,
                P.EMAIL,
                P.USERNAME,
                P.PHONENO,
                P.GENDER,
                L.GRADE,
                CL.ENROLDATE,
                FL.LEAVEGRADE,
                FL.LEAVEDATE,
                S.SCHOOLNAME,
                S.SCHOOL_EMIS,
                LOC.LOCNAME,
                T.TOWNNAME
            FROM dbo.USERS AS U
            INNER JOIN dbo.PERSONS AS P
                ON P.PERSONID = U.PERSONID
            LEFT JOIN dbo.LEARNERS AS L
                ON L.PERSONID = P.PERSONID
            LEFT JOIN dbo.CURRENT_LEARNERS AS CL
                ON CL.LEARNERID = L.LEARNERID
            LEFT JOIN dbo.FORMER_LEARNERS AS FL
                ON FL.LEARNERID = L.LEARNERID
            LEFT JOIN dbo.SCHOOLS AS S
                ON S.SCHOOLID = L.SCHOOLID
            LEFT JOIN dbo.LOCATIONS AS LOC
                ON LOC.LOCID = S.LOCID
            LEFT JOIN dbo.TOWNS AS T
                ON T.TOWNID = LOC.TOWNID
            WHERE U.USERID = ?
            `,
            [req.user.userId]
        );

        const user = getFirstRow(result);

        if (!user) {
            return res.status(404).json({
                success: false,
                message: "User account could not be found."
            });
        }

        if (!user.IS_ACTIVE) {
            return res.status(403).json({
                success: false,
                message: "Your account is inactive."
            });
        }

        return res.status(200).json({
            success: true,
            user: {
                userId: user.USERID,
                personId: user.PERSONID,
                firstName: user.FIRSTNAME,
                lastName: user.LASTNAME,
                email: user.EMAIL,
                username: user.USERNAME,
                phone: user.PHONENO,
                gender: user.GENDER,
                role: user.ROLE,
                isActive: Boolean(user.IS_ACTIVE),

                // Learner information
                grade: user.GRADE || null,
                enrolDate: user.ENROLDATE || null,

                // Former learner information
                leaveGrade: user.LEAVEGRADE || null,
                leaveDate: user.LEAVEDATE || null,

                // School information
                schoolName: user.SCHOOLNAME || null,
                schoolEmis: user.SCHOOL_EMIS || null,
                locationName: user.LOCNAME || null,
                townName: user.TOWNNAME || null
            }
        });
    } catch (error) {
        console.error("GET CURRENT USER ERROR:", error);

        return res.status(500).json({
            success: false,
            message: "Unable to retrieve your account information."
        });
    } finally {
        if (connection) {
            try {
                await connection.promises.close();
            } catch (closeError) {
                console.error("DATABASE CLOSE ERROR:", closeError);
            }
        }
    }
});

module.exports = router;