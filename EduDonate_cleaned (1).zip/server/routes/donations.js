const express = require("express");
const sql = require("msnodesqlv8");

const { connectionString } = require("../config/db");
const {
    authenticateToken,
    requireRole
} = require("../middleware/authMiddleware");

const router = express.Router();

const ALLOWED_DONATION_STATUSES = [
    "PENDING",
    "RECEIVED",
    "REJECTED",
    "PARTIAL",
    "DISTRIBUTED",
    "COMPLETED"
];

/* =========================================
   DATABASE HELPERS
========================================= */

async function openDatabaseConnection() {
    return sql.promises.open(connectionString);
}

function rowsOf(result) {
    return result && Array.isArray(result.first)
        ? result.first
        : [];
}

function firstRow(result) {
    return rowsOf(result)[0] || null;
}

function numericId(value) {
    const number = Number(value);

    return Number.isSafeInteger(number) && number > 0
        ? number
        : null;
}

function normalizedRole(req) {
    return String(
        (req.user && req.user.role) || ""
    ).trim().toUpperCase();
}

function dateOnly(value) {
    if (!value) return null;

    if (
        value instanceof Date &&
        !Number.isNaN(value.getTime())
    ) {
        return value.toISOString().slice(0, 10);
    }

    const text = String(value).trim();
    const match = text.match(/^(\d{4}-\d{2}-\d{2})/);

    return match ? match[1] : null;
}

async function getFormerLearner(connection, personId) {
    const result = await connection.promises.query(
        `
        SELECT TOP 1
            F.FORMERID,
            F.LEARNERID,
            L.SCHOOLID
        FROM dbo.FORMER_LEARNERS AS F
        INNER JOIN dbo.LEARNERS AS L
            ON L.LEARNERID = F.LEARNERID
        WHERE L.PERSONID = ?
        `,
        [personId]
    );

    return firstRow(result);
}

async function getCoordinator(connection, personId) {
    const result = await connection.promises.query(
        `
        SELECT TOP 1
            DCID,
            PERSONID,
            SCHOOLID,
            STATUS
        FROM dbo.DONATION_COORDINATORS
        WHERE PERSONID = ?
        `,
        [personId]
    );

    return firstRow(result);
}

async function getCurrentLearner(connection, personId) {
    const result = await connection.promises.query(
        `
        SELECT TOP 1
            C.CURRENTID,
            C.LEARNERID,
            L.PERSONID,
            L.SCHOOLID
        FROM dbo.CURRENT_LEARNERS AS C
        INNER JOIN dbo.LEARNERS AS L
            ON L.LEARNERID = C.LEARNERID
        WHERE L.PERSONID = ?
        `,
        [personId]
    );

    return firstRow(result);
}

async function getCategory(connection, categoryId) {
    const result = await connection.promises.query(
        `
        SELECT TOP 1
            CAID,
            UNIFORM_ID,
            STATIONARY_ID
        FROM dbo.CATEGORIES
        WHERE CAID = ?
        `,
        [categoryId]
    );

    return firstRow(result);
}

async function getItemSize(connection, sizeId) {
    const result = await connection.promises.query(
        `
        SELECT TOP 1
            ITSID,
            ITEMSIZE
        FROM dbo.ITEMSIZES
        WHERE ITSID = ?
        `,
        [sizeId]
    );

    return firstRow(result);
}

async function getDonationById(connection, donationId) {
    const result = await connection.promises.query(
        `
        SELECT TOP 1 *
        FROM dbo.VW_FORMER_LEARNER_DONATIONS
        WHERE DONATIONID = ?
        `,
        [donationId]
    );

    return firstRow(result);
}

async function isDonationOwner(
    connection,
    donationId,
    personId
) {
    const result = await connection.promises.query(
        `
        SELECT TOP 1
            D.DONATIONID
        FROM dbo.ITEMDONATIONS AS D
        INNER JOIN dbo.FORMER_LEARNERS AS F
            ON F.FORMERID = D.FORMERID
        INNER JOIN dbo.LEARNERS AS L
            ON L.LEARNERID = F.LEARNERID
        WHERE D.DONATIONID = ?
          AND L.PERSONID = ?
        `,
        [donationId, personId]
    );

    return Boolean(firstRow(result));
}

async function getDistributedQuantity(
    connection,
    donationId
) {
    const result = await connection.promises.query(
        `
        SELECT
            COALESCE(SUM(QUANTITY), 0)
                AS DISTRIBUTED_QUANTITY
        FROM dbo.DISTRIBUTIONS
        WHERE DONATIONID = ?
          AND CONFIRMATION = 'DISTRIBUTED'
        `,
        [donationId]
    );

    const row = firstRow(result);

    return row
        ? Number(row.DISTRIBUTED_QUANTITY || 0)
        : 0;
}

function donationItemDetails(category) {
    if (category.UNIFORM_ID != null) {
        return {
            itemId: category.UNIFORM_ID,
            itemType: "UNIFORM"
        };
    }

    if (category.STATIONARY_ID != null) {
        return {
            itemId: category.STATIONARY_ID,
            itemType: "STATIONERY"
        };
    }

    return {
        itemId: null,
        itemType: "OTHER"
    };
}

function sendError(
    res,
    error,
    logLabel,
    userMessage
) {
    console.error(logLabel, error);

    return res.status(500).json({
        success: false,
        message: userMessage
    });
}

/* =========================================
   GET /api/donations

   ADMIN:
       Views all donations.

   COORDINATOR:
       Views donations for their assigned school.

   FORMER_LEARNER:
       Views their own donations.

   LEARNER:
       Views available donations for their school.
========================================= */

router.get("/", authenticateToken, async (req, res) => {
    let connection;

    try {
        connection = await openDatabaseConnection();

        const role = normalizedRole(req);

        if (role === "ADMIN") {
            const result = await connection.promises.query(
                `
                SELECT *
                FROM dbo.VW_FORMER_LEARNER_DONATIONS
                ORDER BY DONATIONID DESC
                `
            );

            return res.status(200).json({
                success: true,
                donations: rowsOf(result)
            });
        }

        if (role === "COORDINATOR") {
            const coordinator = await getCoordinator(
                connection,
                req.user.personId
            );

            if (
                !coordinator ||
                String(coordinator.STATUS).toUpperCase() !== "ACTIVE"
            ) {
                return res.status(403).json({
                    success: false,
                    message:
                        "Active coordinator profile could not be found."
                });
            }

            const result = await connection.promises.query(
                `
                SELECT D.*
                FROM dbo.VW_FORMER_LEARNER_DONATIONS AS D
                INNER JOIN dbo.ITEMDONATIONS AS I
                    ON I.DONATIONID = D.DONATIONID
                WHERE I.SCHOOLID = ?
                ORDER BY D.DONATIONID DESC
                `,
                [coordinator.SCHOOLID]
            );

            return res.status(200).json({
                success: true,
                donations: rowsOf(result)
            });
        }

        if (role === "FORMER_LEARNER") {
            const result = await connection.promises.query(
                `
                SELECT D.*
                FROM dbo.VW_FORMER_LEARNER_DONATIONS AS D
                INNER JOIN dbo.ITEMDONATIONS AS I
                    ON I.DONATIONID = D.DONATIONID
                INNER JOIN dbo.FORMER_LEARNERS AS F
                    ON F.FORMERID = I.FORMERID
                INNER JOIN dbo.LEARNERS AS L
                    ON L.LEARNERID = F.LEARNERID
                WHERE L.PERSONID = ?
                ORDER BY D.DONATIONID DESC
                `,
                [req.user.personId]
            );

            return res.status(200).json({
                success: true,
                donations: rowsOf(result)
            });
        }

        if (role === "LEARNER") {
            const learner = await getCurrentLearner(
                connection,
                req.user.personId
            );

            if (!learner) {
                return res.status(403).json({
                    success: false,
                    message:
                        "Your account is not linked to a current learner profile."
                });
            }

            const result = await connection.promises.query(
                `
                SELECT
                    V.DONATIONID,
                    V.SCHOOLID,
                    V.CAID,
                    D.ITSID,
                    V.ITEM_NAME,
                    V.CATEGORY,
                    V.ITEM_SIZE,
                    V.[CONDITION],

                    D.QUANTITY -
                        COALESCE(
                            X.DISTRIBUTED_QUANTITY,
                            0
                        ) AS QUANTITY,

                    V.DONATIONDATE,
                    D.CONFIRMATION

                FROM dbo.VW_AVAILABLE_DONATIONS AS V

                INNER JOIN dbo.ITEMDONATIONS AS D
                    ON D.DONATIONID = V.DONATIONID

                OUTER APPLY (
                    SELECT
                        SUM(DIST.QUANTITY)
                            AS DISTRIBUTED_QUANTITY
                    FROM dbo.DISTRIBUTIONS AS DIST
                    WHERE DIST.DONATIONID = D.DONATIONID
                      AND DIST.CONFIRMATION = 'DISTRIBUTED'
                ) AS X

                WHERE D.SCHOOLID = ?
                  AND D.CONFIRMATION IN ('RECEIVED', 'PARTIAL')
                  AND D.QUANTITY >
                      COALESCE(X.DISTRIBUTED_QUANTITY, 0)

                ORDER BY
                    D.DONATIONDATE DESC,
                    D.DONATIONID DESC
                `,
                [learner.SCHOOLID]
            );

            return res.status(200).json({
                success: true,
                donations: rowsOf(result)
            });
        }

        return res.status(403).json({
            success: false,
            message:
                "You do not have permission to access donations."
        });
    } catch (error) {
        return sendError(
            res,
            error,
            "GET DONATIONS ERROR:",
            "Unable to retrieve donations."
        );
    } finally {
        if (connection) {
            try {
                await connection.promises.close();
            } catch (error) {
                console.error("DATABASE CLOSE ERROR:", error);
            }
        }
    }
});

/* =========================================
   GET /api/donations/options

   Loads categories and sizes for the
   Former Learner donation form.
========================================= */

router.get(
    "/options",
    authenticateToken,
    requireRole("FORMER_LEARNER"),
    async (req, res) => {
        let connection;

        try {
            connection = await openDatabaseConnection();

            const formerLearner = await getFormerLearner(
                connection,
                req.user.personId
            );

            if (!formerLearner) {
                return res.status(403).json({
                    success: false,
                    message:
                        "Your account is not linked to a former learner profile."
                });
            }

            const categoryResult =
                await connection.promises.query(
                    `
                    SELECT
                        CAID,
                        ITEM_NAME,
                        ITEM_CATEGORY
                    FROM dbo.VW_DONATION_CATEGORIES
                    ORDER BY ITEM_CATEGORY, ITEM_NAME
                    `
                );

            const sizeResult =
                await connection.promises.query(
                    `
                    SELECT
                        ITSID,
                        ITEMSIZE
                    FROM dbo.ITEMSIZES
                    ORDER BY ITSID
                    `
                );

            return res.status(200).json({
                success: true,
                categories: rowsOf(categoryResult),
                sizes: rowsOf(sizeResult)
            });
        } catch (error) {
            return sendError(
                res,
                error,
                "LOAD DONATION OPTIONS ERROR:",
                "Unable to load donation categories and sizes."
            );
        } finally {
            if (connection) {
                try {
                    await connection.promises.close();
                } catch (error) {
                    console.error("DATABASE CLOSE ERROR:", error);
                }
            }
        }
    }
);

/* =========================================
   GET /api/donations/profile

   Returns the logged-in Former Learner's
   profile from the existing database view.
========================================= */

router.get(
    "/profile",
    authenticateToken,
    requireRole("FORMER_LEARNER"),
    async (req, res) => {
        let connection;

        try {
            connection = await openDatabaseConnection();

            const result = await connection.promises.query(
                `
                SELECT TOP 1 *
                FROM dbo.VW_FORMER_LEARNER_PROFILE
                WHERE PERSONID = ?
                `,
                [req.user.personId]
            );

            const profile = firstRow(result);

            if (!profile) {
                return res.status(404).json({
                    success: false,
                    message: "Former Learner profile not found."
                });
            }

            return res.status(200).json({
                success: true,
                profile
            });
        } catch (error) {
            return sendError(
                res,
                error,
                "GET FORMER LEARNER PROFILE ERROR:",
                "Unable to load your profile."
            );
        } finally {
            if (connection) {
                try {
                    await connection.promises.close();
                } catch (error) {
                    console.error("DATABASE CLOSE ERROR:", error);
                }
            }
        }
    }
);

/* =========================================
   GET /api/donations/:id

   Retrieves one donation after verifying
   that the user is allowed to access it.
========================================= */

router.get("/:id", authenticateToken, async (req, res) => {
    let connection;

    try {
        const donationId = numericId(req.params.id);

        if (!donationId) {
            return res.status(400).json({
                success: false,
                message: "Invalid donation ID."
            });
        }

        connection = await openDatabaseConnection();

        const donation = await getDonationById(
            connection,
            donationId
        );

        if (!donation) {
            return res.status(404).json({
                success: false,
                message: "Donation not found."
            });
        }

        const role = normalizedRole(req);

        if (role === "ADMIN") {
            return res.status(200).json({
                success: true,
                donation
            });
        }

        if (role === "COORDINATOR") {
            const coordinator = await getCoordinator(
                connection,
                req.user.personId
            );

            if (
                !coordinator ||
                String(coordinator.STATUS).toUpperCase() !== "ACTIVE"
            ) {
                return res.status(403).json({
                    success: false,
                    message:
                        "Active coordinator profile could not be found."
                });
            }

            const schoolCheck =
                await connection.promises.query(
                    `
                    SELECT TOP 1 DONATIONID
                    FROM dbo.ITEMDONATIONS
                    WHERE DONATIONID = ?
                      AND SCHOOLID = ?
                    `,
                    [
                        donationId,
                        coordinator.SCHOOLID
                    ]
                );

            if (!firstRow(schoolCheck)) {
                return res.status(403).json({
                    success: false,
                    message:
                        "You cannot access donations from another school."
                });
            }

            return res.status(200).json({
                success: true,
                donation
            });
        }

        if (role === "FORMER_LEARNER") {
            const ownsDonation = await isDonationOwner(
                connection,
                donationId,
                req.user.personId
            );

            if (!ownsDonation) {
                return res.status(403).json({
                    success: false,
                    message:
                        "You cannot access another donor's donation."
                });
            }

            return res.status(200).json({
                success: true,
                donation
            });
        }

        if (role === "LEARNER") {
            const learner = await getCurrentLearner(
                connection,
                req.user.personId
            );

            const underlyingResult =
                await connection.promises.query(
                    `
                    SELECT TOP 1
                        SCHOOLID,
                        CONFIRMATION
                    FROM dbo.ITEMDONATIONS
                    WHERE DONATIONID = ?
                    `,
                    [donationId]
                );

            const item = firstRow(underlyingResult);

            if (
                !learner ||
                !item ||
                Number(item.SCHOOLID) !== Number(learner.SCHOOLID) ||
                !["RECEIVED", "PARTIAL"].includes(
                    String(item.CONFIRMATION).toUpperCase()
                )
            ) {
                return res.status(403).json({
                    success: false,
                    message:
                        "This donation is not available to your school."
                });
            }

            return res.status(200).json({
                success: true,
                donation
            });
        }

        return res.status(403).json({
            success: false,
            message:
                "You do not have permission to access this donation."
        });
    } catch (error) {
        return sendError(
            res,
            error,
            "GET DONATION ERROR:",
            "Unable to retrieve the donation."
        );
    } finally {
        if (connection) {
            try {
                await connection.promises.close();
            } catch (error) {
                console.error("DATABASE CLOSE ERROR:", error);
            }
        }
    }
});

/* =========================================
   POST /api/donations

   Creates a new donation for a Former Learner.
   The server determines the donor and school
   from the authenticated account.
========================================= */

router.post(
    "/",
    authenticateToken,
    requireRole("FORMER_LEARNER"),
    async (req, res) => {
        let connection;

        try {
            const {
                categoryId,
                sizeId,
                condition,
                quantity,
                donationDate
            } = req.body || {};

            const parsedCategoryId = numericId(categoryId);
            const parsedSizeId = numericId(sizeId);
            const parsedQuantity = Number(quantity);
            const cleanCondition = String(condition || "").trim();

            const cleanDonationDate =
                donationDate == null || donationDate === ""
                    ? new Date().toISOString().slice(0, 10)
                    : String(donationDate).trim();

            if (
                !parsedCategoryId ||
                !parsedSizeId ||
                !cleanCondition ||
                quantity === undefined ||
                quantity === null ||
                quantity === ""
            ) {
                return res.status(400).json({
                    success: false,
                    message:
                        "Category, size, condition and quantity are required."
                });
            }

            if (
                !Number.isSafeInteger(parsedQuantity) ||
                parsedQuantity <= 0
            ) {
                return res.status(400).json({
                    success: false,
                    message:
                        "Quantity must be a whole number greater than zero."
                });
            }

            if (cleanCondition.length > 100) {
                return res.status(400).json({
                    success: false,
                    message:
                        "Condition must not exceed 100 characters."
                });
            }

            if (
                !/^\d{4}-\d{2}-\d{2}$/.test(cleanDonationDate) ||
                Number.isNaN(
                    Date.parse(`${cleanDonationDate}T00:00:00`)
                )
            ) {
                return res.status(400).json({
                    success: false,
                    message:
                        "Donation date must use YYYY-MM-DD format."
                });
            }

            connection = await openDatabaseConnection();

            const formerLearner = await getFormerLearner(
                connection,
                req.user.personId
            );

            if (!formerLearner) {
                return res.status(403).json({
                    success: false,
                    message:
                        "Your account is not linked to a former learner profile."
                });
            }

            const category = await getCategory(
                connection,
                parsedCategoryId
            );

            if (!category) {
                return res.status(400).json({
                    success: false,
                    message:
                        "The selected category does not exist."
                });
            }

            const itemSize = await getItemSize(
                connection,
                parsedSizeId
            );

            if (!itemSize) {
                return res.status(400).json({
                    success: false,
                    message:
                        "The selected item size does not exist."
                });
            }

            const { itemId, itemType } =
                donationItemDetails(category);

            if (!itemId) {
                return res.status(400).json({
                    success: false,
                    message:
                        "The selected category is not linked to a uniform or stationery item."
                });
            }

            const result = await connection.promises.query(
                `
                INSERT INTO dbo.ITEMDONATIONS
                (
                    [CONDITION],
                    DONATIONDATE,
                    ITSID,
                    SCHOOLID,
                    FORMERID,
                    CONFIRMATION,
                    QUANTITY,
                    CAID,
                    ITEM_ID,
                    ITEM_TYPE
                )
                OUTPUT
                    INSERTED.DONATIONID,
                    INSERTED.[CONDITION] AS [CONDITION],
                    INSERTED.DONATIONDATE,
                    INSERTED.ITSID,
                    INSERTED.SCHOOLID,
                    INSERTED.FORMERID,
                    INSERTED.CONFIRMATION,
                    INSERTED.QUANTITY,
                    INSERTED.CAID,
                    INSERTED.ITEM_ID,
                    INSERTED.ITEM_TYPE
                VALUES
                (?, ?, ?, ?, ?, 'PENDING', ?, ?, ?, ?)
                `,
                [
                    cleanCondition,
                    cleanDonationDate,
                    parsedSizeId,
                    formerLearner.SCHOOLID,
                    formerLearner.FORMERID,
                    parsedQuantity,
                    parsedCategoryId,
                    itemId,
                    itemType
                ]
            );

            const createdDonation = firstRow(result);

            if (!createdDonation) {
                throw new Error(
                    "Donation insert did not return a row."
                );
            }

            return res.status(201).json({
                success: true,
                message: "Donation submitted successfully.",
                donation: createdDonation
            });
        } catch (error) {
            return sendError(
                res,
                error,
                "CREATE DONATION ERROR:",
                "Unable to create the donation."
            );
        } finally {
            if (connection) {
                try {
                    await connection.promises.close();
                } catch (error) {
                    console.error("DATABASE CLOSE ERROR:", error);
                }
            }
        }
    }
);

/* =========================================
   PUT /api/donations/:id

   Former Learners may edit their own
   pending donations.

   Coordinators may manage donations for
   their assigned school.

   Admins may manage any donation.
========================================= */

router.put("/:id", authenticateToken, async (req, res) => {
    let connection;

    try {
        const donationId = numericId(req.params.id);

        if (!donationId) {
            return res.status(400).json({
                success: false,
                message: "Invalid donation ID."
            });
        }

        const role = normalizedRole(req);

        if (
            !["ADMIN", "COORDINATOR", "FORMER_LEARNER"].includes(role)
        ) {
            return res.status(403).json({
                success: false,
                message:
                    "You do not have permission to modify donations."
            });
        }

        connection = await openDatabaseConnection();

        const existingResult =
            await connection.promises.query(
                `
                SELECT TOP 1 *
                FROM dbo.ITEMDONATIONS
                WHERE DONATIONID = ?
                `,
                [donationId]
            );

        const existing = firstRow(existingResult);

        if (!existing) {
            return res.status(404).json({
                success: false,
                message: "Donation not found."
            });
        }

        if (role === "FORMER_LEARNER") {
            const ownsDonation = await isDonationOwner(
                connection,
                donationId,
                req.user.personId
            );

            if (!ownsDonation) {
                return res.status(403).json({
                    success: false,
                    message:
                        "You cannot modify another donor's donation."
                });
            }

            if (
                String(existing.CONFIRMATION).toUpperCase() !== "PENDING"
            ) {
                return res.status(409).json({
                    success: false,
                    message:
                        "Only pending donations can be edited by the donor."
                });
            }
        } else if (role === "COORDINATOR") {
            const coordinator = await getCoordinator(
                connection,
                req.user.personId
            );

            if (
                !coordinator ||
                String(coordinator.STATUS).toUpperCase() !== "ACTIVE"
            ) {
                return res.status(403).json({
                    success: false,
                    message:
                        "Active coordinator profile could not be found."
                });
            }

            if (
                Number(coordinator.SCHOOLID) !==
                Number(existing.SCHOOLID)
            ) {
                return res.status(403).json({
                    success: false,
                    message:
                        "You cannot modify donations from another school."
                });
            }
        }

        const newCondition =
            req.body.condition !== undefined
                ? String(req.body.condition).trim()
                : String(existing.CONDITION || "").trim();

        const newQuantity =
            req.body.quantity !== undefined
                ? Number(req.body.quantity)
                : Number(existing.QUANTITY);

        const newDonationDate =
            req.body.donationDate !== undefined
                ? String(req.body.donationDate).trim()
                : dateOnly(existing.DONATIONDATE);

        const newCategoryId =
            req.body.categoryId !== undefined
                ? numericId(req.body.categoryId)
                : Number(existing.CAID);

        const newSizeId =
            req.body.sizeId !== undefined
                ? numericId(req.body.sizeId)
                : Number(existing.ITSID);

        if (!newCondition || newCondition.length > 100) {
            return res.status(400).json({
                success: false,
                message:
                    "Condition must be between 1 and 100 characters."
            });
        }

        if (
            !Number.isSafeInteger(newQuantity) ||
            newQuantity <= 0
        ) {
            return res.status(400).json({
                success: false,
                message:
                    "Quantity must be a whole number greater than zero."
            });
        }

        if (
            !newDonationDate ||
            !/^\d{4}-\d{2}-\d{2}$/.test(newDonationDate) ||
            Number.isNaN(
                Date.parse(`${newDonationDate}T00:00:00`)
            )
        ) {
            return res.status(400).json({
                success: false,
                message:
                    "Donation date must use YYYY-MM-DD format."
            });
        }

        if (!newCategoryId || !newSizeId) {
            return res.status(400).json({
                success: false,
                message: "Invalid category or item size."
            });
        }

        const distributedQuantity =
            await getDistributedQuantity(
                connection,
                donationId
            );

        if (newQuantity < distributedQuantity) {
            return res.status(409).json({
                success: false,
                message:
                    `Quantity cannot be lower than the ${distributedQuantity} item(s) already distributed.`
            });
        }

        const category = await getCategory(
            connection,
            newCategoryId
        );

        if (!category) {
            return res.status(400).json({
                success: false,
                message:
                    "The selected category does not exist."
            });
        }

        const size = await getItemSize(
            connection,
            newSizeId
        );

        if (!size) {
            return res.status(400).json({
                success: false,
                message:
                    "The selected item size does not exist."
            });
        }

        const { itemId, itemType } =
            donationItemDetails(category);

        if (!itemId) {
            return res.status(400).json({
                success: false,
                message:
                    "The selected category is not linked to a uniform or stationery item."
            });
        }

        let newStatus = String(
            existing.CONFIRMATION || "PENDING"
        ).toUpperCase();

        if (role === "ADMIN" || role === "COORDINATOR") {
            if (req.body.confirmation !== undefined) {
                newStatus = String(
                    req.body.confirmation
                ).trim().toUpperCase();
            }
        } else if (req.body.confirmation !== undefined) {
            return res.status(403).json({
                success: false,
                message:
                    "Donors cannot change donation confirmation status."
            });
        }

        if (!ALLOWED_DONATION_STATUSES.includes(newStatus)) {
            return res.status(400).json({
                success: false,
                message: "Invalid donation status."
            });
        }

        const result = await connection.promises.query(
            `
            UPDATE dbo.ITEMDONATIONS
            SET
                [CONDITION] = ?,
                DONATIONDATE = ?,
                ITSID = ?,
                CONFIRMATION = ?,
                QUANTITY = ?,
                CAID = ?,
                ITEM_ID = ?,
                ITEM_TYPE = ?
            OUTPUT
                INSERTED.DONATIONID,
                INSERTED.[CONDITION] AS [CONDITION],
                INSERTED.DONATIONDATE,
                INSERTED.ITSID,
                INSERTED.SCHOOLID,
                INSERTED.FORMERID,
                INSERTED.CONFIRMATION,
                INSERTED.QUANTITY,
                INSERTED.CAID,
                INSERTED.ITEM_ID,
                INSERTED.ITEM_TYPE
            WHERE DONATIONID = ?
            `,
            [
                newCondition,
                newDonationDate,
                newSizeId,
                newStatus,
                newQuantity,
                newCategoryId,
                itemId,
                itemType,
                donationId
            ]
        );

        return res.status(200).json({
            success: true,
            message: "Donation updated successfully.",
            donation: firstRow(result)
        });
    } catch (error) {
        return sendError(
            res,
            error,
            "UPDATE DONATION ERROR:",
            "Unable to update the donation."
        );
    } finally {
        if (connection) {
            try {
                await connection.promises.close();
            } catch (error) {
                console.error("DATABASE CLOSE ERROR:", error);
            }
        }
    }
});

/* =========================================
   DELETE /api/donations/:id

   Former Learners:
       May delete their own pending donations.

   Coordinators:
       May delete donations for their school.

   Admin:
       May delete donations, provided no
       distribution history exists.
========================================= */

router.delete("/:id", authenticateToken, async (req, res) => {
    let connection;

    try {
        const donationId = numericId(req.params.id);

        if (!donationId) {
            return res.status(400).json({
                success: false,
                message: "Invalid donation ID."
            });
        }

        const role = normalizedRole(req);

        if (
            !["ADMIN", "COORDINATOR", "FORMER_LEARNER"].includes(role)
        ) {
            return res.status(403).json({
                success: false,
                message:
                    "You do not have permission to delete donations."
            });
        }

        connection = await openDatabaseConnection();

        const existingResult =
            await connection.promises.query(
                `
                SELECT TOP 1 *
                FROM dbo.ITEMDONATIONS
                WHERE DONATIONID = ?
                `,
                [donationId]
            );

        const existing = firstRow(existingResult);

        if (!existing) {
            return res.status(404).json({
                success: false,
                message: "Donation not found."
            });
        }

        if (role === "FORMER_LEARNER") {
            const ownsDonation = await isDonationOwner(
                connection,
                donationId,
                req.user.personId
            );

            if (!ownsDonation) {
                return res.status(403).json({
                    success: false,
                    message:
                        "You cannot delete another donor's donation."
                });
            }

            if (
                String(existing.CONFIRMATION).toUpperCase() !== "PENDING"
            ) {
                return res.status(409).json({
                    success: false,
                    message:
                        "Only pending donations can be deleted."
                });
            }
        } else if (role === "COORDINATOR") {
            const coordinator = await getCoordinator(
                connection,
                req.user.personId
            );

            if (
                !coordinator ||
                String(coordinator.STATUS).toUpperCase() !== "ACTIVE"
            ) {
                return res.status(403).json({
                    success: false,
                    message:
                        "Active coordinator profile could not be found."
                });
            }

            if (
                Number(coordinator.SCHOOLID) !==
                Number(existing.SCHOOLID)
            ) {
                return res.status(403).json({
                    success: false,
                    message:
                        "You cannot delete donations from another school."
                });
            }
        }

        const distributionCheck =
            await connection.promises.query(
                `
                SELECT TOP 1 DISTRIBUTIONID
                FROM dbo.DISTRIBUTIONS
                WHERE DONATIONID = ?
                `,
                [donationId]
            );

        if (firstRow(distributionCheck)) {
            return res.status(409).json({
                success: false,
                message:
                    "This donation has distribution history and cannot be deleted."
            });
        }

        await connection.promises.query(
            `
            DELETE FROM dbo.ITEMDONATIONS
            WHERE DONATIONID = ?
            `,
            [donationId]
        );

        return res.status(200).json({
            success: true,
            message: "Donation deleted successfully."
        });
    } catch (error) {
        return sendError(
            res,
            error,
            "DELETE DONATION ERROR:",
            "Unable to delete the donation."
        );
    } finally {
        if (connection) {
            try {
                await connection.promises.close();
            } catch (error) {
                console.error("DATABASE CLOSE ERROR:", error);
            }
        }
    }
});

module.exports = router;