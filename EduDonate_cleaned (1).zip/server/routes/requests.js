"use strict";

const express = require("express");
const sql = require("msnodesqlv8");

const { connectionString } = require("../config/db");
const {
    authenticateToken,
    requireRole
} = require("../middleware/authMiddleware");

const router = express.Router();

// Statuses that staff can set manually.
// COLLECTED is handled by the distribution workflow.
const ALLOWED_STATUSES = ["PENDING", "APPROVED", "REJECTED"];

async function openDatabaseConnection() {
    return sql.promises.open(connectionString);
}

function getRows(result) {
    return result && Array.isArray(result.first) ? result.first : [];
}

function getFirstRow(result) {
    return getRows(result)[0] || null;
}

function getRole(req) {
    return String(req.user?.role || "")
        .trim()
        .toUpperCase();
}

async function getCurrentLearner(connection, personId) {
    const result = await connection.promises.query(
        `
        SELECT TOP 1
            C.CURRENTID,
            C.LEARNERID,
            L.PERSONID,
            L.SCHOOLID
        FROM dbo.CURRENT_LEARNERS AS C
        INNER JOIN dbo.LEARNERS AS L
            ON C.LEARNERID = L.LEARNERID
        WHERE L.PERSONID = ?
        `,
        [personId]
    );

    return getFirstRow(result);
}

async function getCoordinator(connection, personId) {
    const result = await connection.promises.query(
        `
        SELECT TOP 1
            DCID,
            PERSONID,
            SCHOOLID,
            STATUS
        FROM dbo.DONATION_COORDINATORS
        WHERE PERSONID = ?
        `,
        [personId]
    );

    return getFirstRow(result);
}

async function getCategory(connection, categoryId) {
    const result = await connection.promises.query(
        `
        SELECT TOP 1 CAID
        FROM dbo.CATEGORIES
        WHERE CAID = ?
        `,
        [categoryId]
    );

    return getFirstRow(result);
}

async function getItemSize(connection, sizeId) {
    const result = await connection.promises.query(
        `
        SELECT TOP 1 ITSID
        FROM dbo.ITEMSIZES
        WHERE ITSID = ?
        `,
        [sizeId]
    );

    return getFirstRow(result);
}

function sendDatabaseError(res, error, label, message) {
    console.error(`${label}:`, error);

    return res.status(500).json({
        success: false,
        message
    });
}

async function closeConnection(connection) {
    if (!connection) {
        return;
    }

    try {
        await connection.promises.close();
    } catch (error) {
        console.error("DATABASE CLOSE ERROR:", error);
    }
}

/**
 * GET /api/requests
 *
 * LEARNER:
 *     Views their own requests.
 *
 * COORDINATOR:
 *     Views requests from their school.
 *
 * ADMIN:
 *     Views all requests.
 */
router.get("/", authenticateToken, async (req, res) => {
    let connection = null;

    try {
        connection = await openDatabaseConnection();

        const role = getRole(req);

        // LEARNER: Retrieve requests belonging to the signed-in learner.
        if (role === "LEARNER") {
            const learner = await getCurrentLearner(
                connection,
                req.user.personId
            );

            if (!learner) {
                return res.status(403).json({
                    success: false,
                    message:
                        "Your account is not linked to a current learner profile."
                });
            }

            const result = await connection.promises.query(
                `
                SELECT *
                FROM dbo.VW_CURRENT_LEARNER_REQUESTS
                WHERE CURRENTID = ?
                ORDER BY REQUESTID DESC
                `,
                [learner.CURRENTID]
            );

            return res.status(200).json({
                success: true,
                requests: getRows(result)
            });
        }

        // COORDINATOR: Retrieve requests belonging to their school.
        if (role === "COORDINATOR") {
            const coordinator = await getCoordinator(
                connection,
                req.user.personId
            );

            if (!coordinator) {
                return res.status(403).json({
                    success: false,
                    message: "Coordinator profile could not be found."
                });
            }

            if (
                String(coordinator.STATUS || "")
                    .trim()
                    .toUpperCase() !== "ACTIVE"
            ) {
                return res.status(403).json({
                    success: false,
                    message: "Your coordinator account is inactive."
                });
            }

            const result = await connection.promises.query(
                `
                SELECT
                    V.*,
                    P.FIRSTNAME AS LEARNER_FIRSTNAME,
                    P.LASTNAME AS LEARNER_LASTNAME,
                    LTRIM(RTRIM(CONCAT(
                        COALESCE(P.FIRSTNAME, ''),
                        ' ',
                        COALESCE(P.LASTNAME, '')
                    ))) AS LEARNER_NAME
                FROM dbo.VW_CURRENT_LEARNER_REQUESTS AS V
                INNER JOIN dbo.CURRENT_LEARNERS AS C
                    ON V.CURRENTID = C.CURRENTID
                INNER JOIN dbo.LEARNERS AS L
                    ON C.LEARNERID = L.LEARNERID
                INNER JOIN dbo.PERSONS AS P
                    ON L.PERSONID = P.PERSONID
                WHERE L.SCHOOLID = ?
                ORDER BY V.REQUESTID DESC
                `,
                [coordinator.SCHOOLID]
            );

            return res.status(200).json({
                success: true,
                requests: getRows(result)
            });
        }

        // ADMIN: Retrieve all requests.
        if (role === "ADMIN") {
            const result = await connection.promises.query(
                `
                SELECT *
                FROM dbo.VW_CURRENT_LEARNER_REQUESTS
                ORDER BY REQUESTID DESC
                `
            );

            return res.status(200).json({
                success: true,
                requests: getRows(result)
            });
        }

        return res.status(403).json({
            success: false,
            message: "You do not have permission to view requests."
        });
    } catch (error) {
        return sendDatabaseError(
            res,
            error,
            "GET REQUESTS ERROR",
            "Unable to retrieve requests."
        );
    } finally {
        await closeConnection(connection);
    }
});

/**
 * GET /api/requests/:id
 *
 * Retrieves one request after checking permissions.
 */
router.get("/:id", authenticateToken, async (req, res) => {
    let connection = null;

    try {
        const requestId = Number(req.params.id);

        if (
            !Number.isSafeInteger(requestId) ||
            requestId <= 0
        ) {
            return res.status(400).json({
                success: false,
                message: "Invalid request ID."
            });
        }

        connection = await openDatabaseConnection();

        const result = await connection.promises.query(
            `
            SELECT TOP 1 *
            FROM dbo.VW_CURRENT_LEARNER_REQUESTS
            WHERE REQUESTID = ?
            `,
            [requestId]
        );

        const request = getFirstRow(result);

        if (!request) {
            return res.status(404).json({
                success: false,
                message: "Request not found."
            });
        }

        const role = getRole(req);

        // Check learner ownership.
        if (role === "LEARNER") {
            const learner = await getCurrentLearner(
                connection,
                req.user.personId
            );

            if (!learner) {
                return res.status(403).json({
                    success: false,
                    message: "Your learner profile could not be found."
                });
            }

            if (
                Number(request.CURRENTID) !==
                Number(learner.CURRENTID)
            ) {
                return res.status(403).json({
                    success: false,
                    message:
                        "You cannot access another learner's request."
                });
            }
        } else if (role === "COORDINATOR") {
            const coordinator = await getCoordinator(
                connection,
                req.user.personId
            );

            if (!coordinator) {
                return res.status(403).json({
                    success: false,
                    message: "Coordinator profile could not be found."
                });
            }

            if (
                String(coordinator.STATUS || "")
                    .trim()
                    .toUpperCase() !== "ACTIVE"
            ) {
                return res.status(403).json({
                    success: false,
                    message: "Your coordinator account is inactive."
                });
            }

            if (
                Number(request.SCHOOLID) !==
                Number(coordinator.SCHOOLID)
            ) {
                return res.status(403).json({
                    success: false,
                    message:
                        "You cannot access requests from another school."
                });
            }
        } else if (role !== "ADMIN") {
            return res.status(403).json({
                success: false,
                message:
                    "You do not have permission to access this request."
            });
        }

        return res.status(200).json({
            success: true,
            request
        });
    } catch (error) {
        return sendDatabaseError(
            res,
            error,
            "GET REQUEST ERROR",
            "Unable to retrieve this request."
        );
    } finally {
        await closeConnection(connection);
    }
});

/**
 * POST /api/requests
 *
 * Only LEARNER accounts can create requests.
 *
 * CURRENTID and SCHOOLID are obtained from the learner's profile,
 * not trusted from the browser.
 */
router.post(
    "/",
    authenticateToken,
    requireRole("LEARNER"),
    async (req, res) => {
        let connection = null;

        try {
            const categoryId = Number(req.body?.categoryId);
            const sizeId = Number(req.body?.sizeId);
            const quantity = Number(req.body?.quantity);

            const requestNote =
                req.body?.requestNote == null
                    ? null
                    : String(req.body.requestNote).trim();

            // Validate required fields.
            if (
                req.body?.categoryId === undefined ||
                req.body?.sizeId === undefined ||
                req.body?.quantity === undefined
            ) {
                return res.status(400).json({
                    success: false,
                    message:
                        "Category, item size and quantity are required."
                });
            }

            if (
                !Number.isSafeInteger(categoryId) ||
                categoryId <= 0
            ) {
                return res.status(400).json({
                    success: false,
                    message: "Invalid category."
                });
            }

            if (
                !Number.isSafeInteger(sizeId) ||
                sizeId <= 0
            ) {
                return res.status(400).json({
                    success: false,
                    message: "Invalid item size."
                });
            }

            if (
                !Number.isSafeInteger(quantity) ||
                quantity <= 0
            ) {
                return res.status(400).json({
                    success: false,
                    message:
                        "Quantity must be a whole number greater than zero."
                });
            }

            if (
                requestNote !== null &&
                requestNote.length > 200
            ) {
                return res.status(400).json({
                    success: false,
                    message:
                        "Request note cannot exceed 200 characters."
                });
            }

            connection = await openDatabaseConnection();

            // Find the learner using the authenticated person's ID.
            const learner = await getCurrentLearner(
                connection,
                req.user.personId
            );

            if (!learner) {
                return res.status(403).json({
                    success: false,
                    message:
                        "Your account is not linked to a current learner profile."
                });
            }

            // Confirm that the category exists.
            const category = await getCategory(
                connection,
                categoryId
            );

            if (!category) {
                return res.status(400).json({
                    success: false,
                    message:
                        "The selected category does not exist."
                });
            }

            // Confirm that the item size exists.
            const itemSize = await getItemSize(
                connection,
                sizeId
            );

            if (!itemSize) {
                return res.status(400).json({
                    success: false,
                    message:
                        "The selected item size does not exist."
                });
            }

            // Create the request.
            const result = await connection.promises.query(
                `
                INSERT INTO dbo.ITEMREQUESTS
                (
                    STATUS,
                    REQUESTDATE,
                    ITSID,
                    SCHOOLID,
                    CURRENTID,
                    REQUESTNOTE,
                    QUANTITY,
                    CAID
                )
                OUTPUT
                    INSERTED.REQUESTID,
                    INSERTED.STATUS,
                    INSERTED.REQUESTDATE,
                    INSERTED.ITSID,
                    INSERTED.SCHOOLID,
                    INSERTED.CURRENTID,
                    INSERTED.REQUESTNOTE,
                    INSERTED.QUANTITY,
                    INSERTED.CAID
                VALUES
                (
                    'PENDING',
                    CAST(GETDATE() AS DATE),
                    ?,
                    ?,
                    ?,
                    ?,
                    ?,
                    ?
                )
                `,
                [
                    sizeId,
                    learner.SCHOOLID,
                    learner.CURRENTID,
                    requestNote || null,
                    quantity,
                    categoryId
                ]
            );

            const createdRequest = getFirstRow(result);

            if (!createdRequest) {
                throw new Error(
                    "The inserted request was not returned by SQL Server."
                );
            }

            return res.status(201).json({
                success: true,
                message: "Request submitted successfully.",
                request: createdRequest
            });
        } catch (error) {
            return sendDatabaseError(
                res,
                error,
                "CREATE REQUEST ERROR",
                "Unable to create the request."
            );
        } finally {
            await closeConnection(connection);
        }
    }
);

/**
 * PUT /api/requests/:id
 *
 * LEARNER:
 *     Can edit their own pending requests.
 *
 * COORDINATOR:
 *     Can update requests at their own school.
 *
 * ADMIN:
 *     Can update any request.
 */
router.put("/:id", authenticateToken, async (req, res) => {
    let connection = null;

    try {
        const requestId = Number(req.params.id);

        if (
            !Number.isSafeInteger(requestId) ||
            requestId <= 0
        ) {
            return res.status(400).json({
                success: false,
                message: "Invalid request ID."
            });
        }

        connection = await openDatabaseConnection();

        const role = getRole(req);

        // Retrieve the existing request.
        const existingResult = await connection.promises.query(
            `
            SELECT TOP 1
                REQUESTID,
                STATUS,
                REQUESTDATE,
                ITSID,
                SCHOOLID,
                CURRENTID,
                REQUESTNOTE,
                QUANTITY,
                CAID
            FROM dbo.ITEMREQUESTS
            WHERE REQUESTID = ?
            `,
            [requestId]
        );

        const existing = getFirstRow(existingResult);

        if (!existing) {
            return res.status(404).json({
                success: false,
                message: "Request not found."
            });
        }

        // Authorize learner ownership and edit status.
        if (role === "LEARNER") {
            const learner = await getCurrentLearner(
                connection,
                req.user.personId
            );

            if (!learner) {
                return res.status(403).json({
                    success: false,
                    message: "Your learner profile could not be found."
                });
            }

            if (
                Number(existing.CURRENTID) !==
                Number(learner.CURRENTID)
            ) {
                return res.status(403).json({
                    success: false,
                    message:
                        "You cannot modify another learner's request."
                });
            }

            if (
                String(existing.STATUS || "")
                    .trim()
                    .toUpperCase() !== "PENDING"
            ) {
                return res.status(409).json({
                    success: false,
                    message:
                        "Only pending requests can be edited by the learner."
                });
            }
        } else if (role === "COORDINATOR") {
            const coordinator = await getCoordinator(
                connection,
                req.user.personId
            );

            if (!coordinator) {
                return res.status(403).json({
                    success: false,
                    message: "Coordinator profile could not be found."
                });
            }

            if (
                String(coordinator.STATUS || "")
                    .trim()
                    .toUpperCase() !== "ACTIVE"
            ) {
                return res.status(403).json({
                    success: false,
                    message: "Your coordinator account is inactive."
                });
            }

            if (
                Number(existing.SCHOOLID) !==
                Number(coordinator.SCHOOLID)
            ) {
                return res.status(403).json({
                    success: false,
                    message:
                        "You cannot modify requests from another school."
                });
            }
        } else if (role !== "ADMIN") {
            return res.status(403).json({
                success: false,
                message:
                    "You do not have permission to modify requests."
            });
        }

        // Use submitted values when provided.
        // Otherwise, retain the existing values.
        const quantity =
            req.body?.quantity !== undefined
                ? Number(req.body.quantity)
                : Number(existing.QUANTITY);

        const note =
            req.body?.requestNote !== undefined
                ? String(req.body.requestNote ?? "").trim()
                : (
                    existing.REQUESTNOTE == null
                        ? ""
                        : String(existing.REQUESTNOTE)
                );

        const sizeId =
            req.body?.sizeId !== undefined
                ? Number(req.body.sizeId)
                : Number(existing.ITSID);

        const categoryId =
            req.body?.categoryId !== undefined
                ? Number(req.body.categoryId)
                : Number(existing.CAID);

        let status = String(
            existing.STATUS || "PENDING"
        )
            .trim()
            .toUpperCase();

        // Only coordinators and administrators can change the status.
        // COLLECTED is handled by the distribution workflow.
        if (role === "COORDINATOR" || role === "ADMIN") {
            if (req.body?.status !== undefined) {
                status = String(req.body.status)
                    .trim()
                    .toUpperCase();

                if (!ALLOWED_STATUSES.includes(status)) {
                    return res.status(400).json({
                        success: false,
                        message:
                            `Status must be one of: ${ALLOWED_STATUSES.join(", ")}.`
                    });
                }
            }
        }

        // Validate quantity.
        if (
            !Number.isSafeInteger(quantity) ||
            quantity <= 0
        ) {
            return res.status(400).json({
                success: false,
                message:
                    "Quantity must be a whole number greater than zero."
            });
        }

        // Validate note.
        if (note.length > 200) {
            return res.status(400).json({
                success: false,
                message:
                    "Request note cannot exceed 200 characters."
            });
        }

        // Validate item size.
        if (
            !Number.isSafeInteger(sizeId) ||
            sizeId <= 0
        ) {
            return res.status(400).json({
                success: false,
                message: "Invalid item size."
            });
        }

        // Validate category.
        if (
            !Number.isSafeInteger(categoryId) ||
            categoryId <= 0
        ) {
            return res.status(400).json({
                success: false,
                message: "Invalid category."
            });
        }

        // Confirm the category exists.
        const category = await getCategory(
            connection,
            categoryId
        );

        if (!category) {
            return res.status(400).json({
                success: false,
                message: "The selected category does not exist."
            });
        }

        // Confirm the size exists.
        const itemSize = await getItemSize(
            connection,
            sizeId
        );

        if (!itemSize) {
            return res.status(400).json({
                success: false,
                message: "The selected item size does not exist."
            });
        }

        // Update the request.
        const updateResult = await connection.promises.query(
            `
            UPDATE dbo.ITEMREQUESTS
            SET
                STATUS = ?,
                ITSID = ?,
                REQUESTNOTE = ?,
                QUANTITY = ?,
                CAID = ?
            OUTPUT
                INSERTED.REQUESTID,
                INSERTED.STATUS,
                INSERTED.REQUESTDATE,
                INSERTED.ITSID,
                INSERTED.SCHOOLID,
                INSERTED.CURRENTID,
                INSERTED.REQUESTNOTE,
                INSERTED.QUANTITY,
                INSERTED.CAID
            WHERE REQUESTID = ?
            `,
            [
                status,
                sizeId,
                note || null,
                quantity,
                categoryId,
                requestId
            ]
        );

        const updatedRequest = getFirstRow(updateResult);

        if (!updatedRequest) {
            return res.status(404).json({
                success: false,
                message:
                    "The request was not updated. It may no longer exist."
            });
        }

        return res.status(200).json({
            success: true,
            message: "Request updated successfully.",
            request: updatedRequest
        });
    } catch (error) {
        return sendDatabaseError(
            res,
            error,
            "UPDATE REQUEST ERROR",
            "Unable to update the request."
        );
    } finally {
        await closeConnection(connection);
    }
});

module.exports = router;