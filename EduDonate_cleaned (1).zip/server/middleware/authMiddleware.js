const jwt = require("jsonwebtoken");

/* =========================================
   AUTHENTICATE TOKEN
   Checks whether the user has a valid JWT.
========================================= */

function authenticateToken(req, res, next) {
    const authHeader = req.headers.authorization;

    if (!authHeader || !authHeader.startsWith("Bearer ")) {
        return res.status(401).json({
            success: false,
            message: "Access denied. Please sign in."
        });
    }

    const token = authHeader.slice(7).trim();

    if (!token) {
        return res.status(401).json({
            success: false,
            message: "Authentication token is missing."
        });
    }

    if (!process.env.JWT_SECRET) {
        console.error("JWT_SECRET is not configured.");

        return res.status(500).json({
            success: false,
            message: "Authentication configuration error."
        });
    }

    try {
        const decoded = jwt.verify(
            token,
            process.env.JWT_SECRET
        );

        // Make the authenticated user available to routes.
        req.user = decoded;

        return next();

    } catch (error) {
        if (
            error.name === "TokenExpiredError" ||
            error.name === "JsonWebTokenError" ||
            error.name === "NotBeforeError"
        ) {
            return res.status(401).json({
                success: false,
                message:
                    "Your session is invalid or expired. Please sign in again."
            });
        }

        console.error("AUTHENTICATION ERROR:", error);

        return res.status(500).json({
            success: false,
            message: "Unable to authenticate this request."
        });
    }
}

/* =========================================
   AUTHORIZE ROLE
   Restricts an endpoint to specified roles.

   Example:
   requireRole("COORDINATOR")
========================================= */

function requireRole(...allowedRoles) {
    const roles = allowedRoles
        .flat()
        .map(role => String(role).trim().toUpperCase());

    return function (req, res, next) {
        if (!req.user) {
            return res.status(401).json({
                success: false,
                message: "Please sign in to continue."
            });
        }

        const userRole = String(
            req.user.role || ""
        ).trim().toUpperCase();

        if (!roles.includes(userRole)) {
            return res.status(403).json({
                success: false,
                message:
                    "You do not have permission to perform this action."
            });
        }

        return next();
    };
}

/* =========================================
   EXPORT MIDDLEWARE FUNCTIONS
========================================= */

module.exports = {
    authenticateToken,
    requireRole
};