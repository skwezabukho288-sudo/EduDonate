const sql = require("msnodesqlv8");
require("dotenv").config();

const connectionString =
    "Driver={ODBC Driver 18 for SQL Server};" +
    `Server=${process.env.DB_SERVER};` +
    `Database=${process.env.DB_DATABASE};` +
    "Trusted_Connection=Yes;" +
    "TrustServerCertificate=Yes;";

function connectDatabase() {
    return new Promise((resolve, reject) => {
        console.log("");
        console.log("=================================");
        console.log("   CONNECTING TO SQL SERVER");
        console.log("=================================");
        console.log(`Server: ${process.env.DB_SERVER}`);
        console.log(`Database: ${process.env.DB_DATABASE}`);
        console.log("");

        sql.open(connectionString, (err, connection) => {
            if (err) {
                console.error("DATABASE CONNECTION ERROR:");
                console.error(err);
                reject(err);
                return;
            }

            console.log("SQL SERVER CONNECTION SUCCESSFUL");
            console.log(`Database: ${process.env.DB_DATABASE}`);

            resolve(connection);
        });
    });
}

module.exports = {
    sql,
    connectionString,
    connectDatabase
};