USE EduDonApp;
GO





IF OBJECT_ID('dbo.USERS', 'U') IS NULL
BEGIN

    CREATE TABLE dbo.USERS
    (
        USERID INT IDENTITY(1,1) NOT NULL,

        PERSONID INT NOT NULL,

        PASSWORD_HASH VARCHAR(255) NOT NULL,

        ROLE VARCHAR(30) NOT NULL,

        IS_ACTIVE BIT NOT NULL
            CONSTRAINT DF_USERS_IS_ACTIVE
            DEFAULT 1,

        CREATED_AT DATETIME2 NOT NULL
            CONSTRAINT DF_USERS_CREATED_AT
            DEFAULT SYSDATETIME(),

        LAST_LOGIN DATETIME2 NULL,

        CONSTRAINT PK_USERS
            PRIMARY KEY (USERID),

        CONSTRAINT UQ_USERS_PERSONID
            UNIQUE (PERSONID),

        CONSTRAINT FK_USERS_PERSONS
            FOREIGN KEY (PERSONID)
            REFERENCES dbo.PERSONS(PERSONID),

        CONSTRAINT CK_USERS_ROLE
            CHECK
            (
                ROLE IN
                (
                    'LEARNER',
                    'PARENT',
                    'FORMER_LEARNER',
                    'COORDINATOR',
                    'ADMIN'
                )
            )
    );

    PRINT 'USERS table created successfully.';

END
ELSE
BEGIN

    PRINT 'USERS table already exists.';

END;
GO