
"use strict";

const DONATIONS_API = "http://localhost:3000";

let allDonations = [];
let isLoadingDonations = false;

document.addEventListener("DOMContentLoaded", () => {
    const searchInput = document.getElementById("searchInput");
    const statusFilter = document.getElementById("statusFilter");
    const refreshButton = document.getElementById("refreshBtn");
    const logoutButton = document.getElementById("logoutBtn");
    const menuButton = document.getElementById("dashboardMenuButton");
    const sidebar = document.getElementById("dashboardSidebar");
    const tbody = document.getElementById("donationsTableBody");

    if (searchInput) {
        searchInput.addEventListener("input", renderDonations);
    }

    if (statusFilter) {
        statusFilter.addEventListener("change", renderDonations);
    }

    if (refreshButton) {
        refreshButton.addEventListener("click", loadDonations);
    }

    if (logoutButton) {
        logoutButton.addEventListener("click", logout);
    }

    // Mobile sidebar menu
    if (menuButton && sidebar) {
        menuButton.addEventListener("click", () => {
            const isOpen = sidebar.classList.toggle("open");

            menuButton.setAttribute(
                "aria-expanded",
                String(isOpen)
            );
        });
    }

    // Handle buttons created dynamically inside the donations table.
    if (tbody) {
        tbody.addEventListener("click", event => {
            const target = event.target;

            if (!(target instanceof Element)) {
                return;
            }

            const button = target.closest(
                "button[data-confirm-donation]"
            );

            if (button) {
                confirmDonation(button);
            }
        });
    }

    loadDonations();
});

/* =========================================
   AUTHENTICATION HELPERS
========================================= */

function getToken() {
    return (
        sessionStorage.getItem("edudonate_token") ||
        localStorage.getItem("edudonate_token")
    );
}

function getStoredUser() {
    const raw =
        sessionStorage.getItem("edudonate_user") ||
        localStorage.getItem("edudonate_user");

    try {
        return raw ? JSON.parse(raw) : null;
    } catch (error) {
        console.error("Unable to read stored user:", error);
        return null;
    }
}

function logout() {
    sessionStorage.removeItem("edudonate_token");
    sessionStorage.removeItem("edudonate_user");

    localStorage.removeItem("edudonate_token");
    localStorage.removeItem("edudonate_user");

    window.location.href = "/pages/login.html";
}

/* =========================================
   GENERAL HELPERS
========================================= */

function valueOf(record, ...keys) {
    for (const key of keys) {
        if (
            record &&
            record[key] !== undefined &&
            record[key] !== null
        ) {
            return record[key];
        }
    }

    return "";
}

function normalizeStatus(record) {
    return String(
        valueOf(
            record,
            "CONFIRMATION",
            "STATUS",
            "DONATION_STATUS",
            "confirmation",
            "status"
        ) || "UNKNOWN"
    ).trim().toUpperCase();
}

function setText(id, value, fallback = "—") {
    const element = document.getElementById(id);

    if (element) {
        element.textContent =
            value === null ||
            value === undefined ||
            value === ""
                ? fallback
                : String(value);
    }
}

function showPageMessage(messageText, type = "") {
    const message = document.getElementById("pageMessage");

    if (!message) {
        console.info(messageText);
        return;
    }

    message.textContent = messageText;

    message.classList.add("show");
    message.classList.remove("success", "error", "info");

    if (type) {
        message.classList.add(type);
    }
}

async function readResponse(response) {
    try {
        return await response.json();
    } catch (error) {
        return {};
    }
}

/* =========================================
   LOAD DONATIONS
   GET /api/donations
========================================= */

async function loadDonations() {
    if (isLoadingDonations) {
        return;
    }

    const tbody = document.getElementById("donationsTableBody");
    const token = getToken();

    if (!tbody) {
        console.error(
            "Could not find #donationsTableBody in the HTML."
        );

        showPageMessage(
            "The donations table could not be found.",
            "error"
        );

        return;
    }

    if (!token) {
        window.location.href = "/pages/login.html";
        return;
    }

    isLoadingDonations = true;

    showPageMessage("Loading donations...");

    tbody.innerHTML = `
        <tr>
            <td colspan="9" class="table-empty">
                Loading donations...
            </td>
        </tr>
    `;

    try {
        const response = await fetch(
            `${DONATIONS_API}/api/donations`,
            {
                method: "GET",
                headers: {
                    Authorization: `Bearer ${token}`,
                    Accept: "application/json"
                }
            }
        );

        const result = await readResponse(response);

        if (response.status === 401) {
            logout();
            return;
        }

        if (!response.ok || result.success === false) {
            throw new Error(
                result.message ||
                `Unable to load donations (HTTP ${response.status}).`
            );
        }

        const user = getStoredUser();

        const role = String(
            valueOf(user, "role", "ROLE")
        ).trim().toUpperCase();

        if (!user || role !== "COORDINATOR") {
            throw new Error(
                "This page is only available to Donation Coordinators."
            );
        }

        const coordinatorName =
            valueOf(
                user,
                "firstName",
                "firstname",
                "FIRSTNAME"
            ) ||
            valueOf(user, "username", "USERNAME") ||
            "Donation Coordinator";

        setText(
            "coordinatorName",
            coordinatorName,
            "Donation Coordinator"
        );

        allDonations = Array.isArray(result.donations)
            ? result.donations
            : [];

        updateSummary();
        renderDonations();

        showPageMessage(
            `Loaded ${allDonations.length} donation record(s) for your school.`,
            "success"
        );

    } catch (error) {
        console.error("Load donations error:", error);

        showPageMessage(
            error.message || "Unable to load donations.",
            "error"
        );

        tbody.innerHTML = `
            <tr>
                <td colspan="9" class="table-empty">
                    Could not load donation records.
                    Check the server and try Refresh.
                </td>
            </tr>
        `;

        [
            "totalCount",
            "receivedCount",
            "pendingCount",
            "quantityCount"
        ].forEach(id => {
            setText(id, "—");
        });

    } finally {
        isLoadingDonations = false;
    }
}

/* =========================================
   UPDATE SUMMARY CARDS
========================================= */

function updateSummary() {
    const received = allDonations.filter(record =>
        ["RECEIVED", "PARTIAL"].includes(
            normalizeStatus(record)
        )
    );

    const pending = allDonations.filter(record =>
        normalizeStatus(record) === "PENDING"
    );

    const totalQuantity = allDonations.reduce(
        (sum, record) => {
            return sum + (
                Number(
                    valueOf(record, "QUANTITY", "quantity")
                ) || 0
            );
        },
        0
    );

    setText("totalCount", allDonations.length, "0");
    setText("receivedCount", received.length, "0");
    setText("pendingCount", pending.length, "0");
    setText("quantityCount", totalQuantity, "0");
}

/* =========================================
   SEARCH AND FILTER DONATIONS
========================================= */

function renderDonations() {
    const tbody = document.getElementById("donationsTableBody");

    if (!tbody) {
        return;
    }

    const searchInput = document.getElementById("searchInput");
    const statusFilter = document.getElementById("statusFilter");

    const search = (
        searchInput ? searchInput.value : ""
    ).trim().toLowerCase();

    const selectedStatus = statusFilter
        ? statusFilter.value.trim().toUpperCase()
        : "";

    const filtered = allDonations.filter(record => {
        const id = valueOf(
            record,
            "DONATIONID",
            "DONATION_ID",
            "donationId"
        );

        const item = valueOf(
            record,
            "ITEM_NAME",
            "ITEMNAME",
            "itemName",
            "UNIFORM_TYPE",
            "STATIONARY_TYPE"
        );

        const category = valueOf(
            record,
            "CATEGORY",
            "CATEGORY_NAME",
            "CATEGORYNAME",
            "ITEM_CATEGORY",
            "CATEGORY_TYPE",
            "categoryName"
        );

        const donor = valueOf(
            record,
            "DONOR_NAME",
            "FORMER_LEARNER_NAME",
            "FULL_NAME",
            "LEARNER_NAME",
            "DONORNAME",
            "donorName"
        );

        const status = normalizeStatus(record);

        const searchableText =
            `${id} ${item} ${category} ${donor} ${status}`
                .toLowerCase();

        return (
            searchableText.includes(search) &&
            (!selectedStatus || status === selectedStatus)
        );
    });

    if (filtered.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="9" class="table-empty">
                    No donations match your search.
                </td>
            </tr>
        `;

        return;
    }

    tbody.innerHTML = filtered.map(record => {
        const id = valueOf(
            record,
            "DONATIONID",
            "DONATION_ID",
            "donationId"
        );

        const item = valueOf(
            record,
            "ITEM_NAME",
            "ITEMNAME",
            "itemName",
            "UNIFORM_TYPE",
            "STATIONARY_TYPE"
        ) || "—";

        const category = valueOf(
            record,
            "CATEGORY",
            "CATEGORY_NAME",
            "CATEGORYNAME",
            "ITEM_CATEGORY",
            "CATEGORY_TYPE",
            "UNIFORM_TYPE",
            "STATIONARY_TYPE",
            "categoryName"
        ) || "—";

        const size = valueOf(
            record,
            "ITEM_SIZE",
            "ITEMSIZE",
            "SIZE",
            "itemSize"
        ) || "—";

        const quantity = valueOf(
            record,
            "QUANTITY",
            "quantity"
        );

        const condition = valueOf(
            record,
            "CONDITION",
            "ITEM_CONDITION",
            "condition"
        ) || "—";

        const status = normalizeStatus(record);

        const date = formatDate(
            valueOf(
                record,
                "DONATIONDATE",
                "DONATION_DATE",
                "donationDate"
            )
        );

        const action =
            status === "PENDING" && id !== ""
                ? `
                    <button
                        type="button"
                        class="confirm-receipt-button"
                        data-confirm-donation="${escapeHTML(id)}"
                    >
                        Confirm Receipt
                    </button>
                `
                : "—";

        return `
            <tr>
                <td>${escapeHTML(id || "—")}</td>
                <td><strong>${escapeHTML(item)}</strong></td>
                <td>${escapeHTML(category)}</td>
                <td>${escapeHTML(size)}</td>
                <td>${escapeHTML(quantity === "" ? 0 : quantity)}</td>
                <td>${escapeHTML(condition)}</td>
                <td>
                    <span class="donation-status ${statusClass(status)}">
                        ${escapeHTML(status)}
                    </span>
                </td>
                <td>${escapeHTML(date)}</td>
                <td>${action}</td>
            </tr>
        `;
    }).join("");
}

function statusClass(status) {
    return String(status || "unknown")
        .toLowerCase()
        .replace(/[^a-z0-9_-]/g, "-");
}

/* =========================================
   CONFIRM DONATION RECEIPT
   PUT /api/donations/:id
========================================= */

async function confirmDonation(button) {
    const donationId = button?.dataset?.confirmDonation;

    if (!donationId) {
        return;
    }

    const donation = allDonations.find(record =>
        String(
            valueOf(record, "DONATIONID", "DONATION_ID", "donationId")
        ) === String(donationId)
    );

    if (!donation || normalizeStatus(donation) !== "PENDING") {
        showPageMessage(
            "This donation is no longer pending. Refresh the records.",
            "error"
        );

        await loadDonations();
        return;
    }

    const itemName = valueOf(
        donation,
        "ITEM_NAME",
        "ITEMNAME",
        "itemName",
        "UNIFORM_TYPE",
        "STATIONARY_TYPE"
    ) || "this item";

    const confirmed = window.confirm(
        `Confirm that the school has physically received donation #${donationId} (${itemName})?`
    );

    if (!confirmed) {
        return;
    }

    const token = getToken();

    if (!token) {
        window.location.href = "/pages/login.html";
        return;
    }

    const originalText = button.textContent;

    button.disabled = true;
    button.textContent = "Confirming...";

    showPageMessage("Confirming donation receipt...");

    try {
        const response = await fetch(
            `${DONATIONS_API}/api/donations/${encodeURIComponent(donationId)}`,
            {
                method: "PUT",
                headers: {
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${token}`,
                    Accept: "application/json"
                },

                // The donations API uses req.body.status for status changes.
                body: JSON.stringify({
    confirmation: "RECEIVED"
})
            }
        );

        const result = await readResponse(response);

        if (response.status === 401) {
            logout();
            return;
        }

        if (!response.ok || result.success === false) {
            throw new Error(
                result.message ||
                `Unable to confirm donation receipt (HTTP ${response.status}).`
            );
        }

        await loadDonations();

        showPageMessage(
            `Donation #${donationId} has been confirmed as received.`,
            "success"
        );

    } catch (error) {
        console.error("Confirm donation error:", error);

        showPageMessage(
            error.message || "Unable to confirm donation receipt.",
            "error"
        );

    } finally {
        button.disabled = false;
        button.textContent = originalText || "Confirm Receipt";
    }
}

/* =========================================
   DATE AND HTML HELPERS
========================================= */

function formatDate(value) {
    if (!value) {
        return "—";
    }

    const text = String(value);

    // Display SQL date-only values without timezone shifts.
    const dateOnly = text.match(
        /^(\d{4})-(\d{2})-(\d{2})/
    );

    if (dateOnly) {
        return `${dateOnly[3]}/${dateOnly[2]}/${dateOnly[1]}`;
    }

    const date = new Date(value);

    if (Number.isNaN(date.getTime())) {
        return text;
    }

    return date.toLocaleDateString("en-ZA");
}

function escapeHTML(value) {
    return String(value ?? "").replace(/[&<>"']/g, character => ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#39;"
    })[character]);
}
