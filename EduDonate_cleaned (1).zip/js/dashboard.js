"use strict";

const API_BASE_URL = "http://localhost:3000";

const TOKEN_KEY = "edudonate_token";
const USER_KEY = "edudonate_user";

document.addEventListener("DOMContentLoaded", () => {
    initializeMobileMenu();
    initializeLogout();
    loadDashboard();
});

/* =====================================================
   SESSION HELPERS
===================================================== */

function getToken() {
    return (
        sessionStorage.getItem(TOKEN_KEY) ||
        localStorage.getItem(TOKEN_KEY)
    );
}

function getStoredUser() {
    const stored =
        sessionStorage.getItem(USER_KEY) ||
        localStorage.getItem(USER_KEY);

    try {
        return stored ? JSON.parse(stored) : null;
    } catch (error) {
        console.error("Unable to read stored user:", error);
        return null;
    }
}

function clearSession() {
    sessionStorage.removeItem(TOKEN_KEY);
    sessionStorage.removeItem(USER_KEY);

    localStorage.removeItem(TOKEN_KEY);
    localStorage.removeItem(USER_KEY);
}

function redirectToLogin() {
    window.location.href = "../login.html";
}

function logout() {
    clearSession();
    redirectToLogin();
}

/* =====================================================
   API HELPER
===================================================== */

async function apiGet(endpoint) {
    const token = getToken();

    if (!token) {
        redirectToLogin();
        return null;
    }

    const response = await fetch(
        `${API_BASE_URL}${endpoint}`,
        {
            method: "GET",
            headers: {
                Authorization: `Bearer ${token}`,
                Accept: "application/json"
            }
        }
    );

    if (response.status === 401) {
        clearSession();
        redirectToLogin();
        return null;
    }

    const result = await response.json().catch(() => ({}));

    if (!response.ok || result.success === false) {
        throw new Error(
            result.message ||
            `The request failed with status ${response.status}.`
        );
    }

    return result;
}

/* =====================================================
   LOAD DASHBOARD
===================================================== */

async function loadDashboard() {
    showMessage("Loading your dashboard...");

    try {
        const profileResult = await apiGet("/api/auth/me");

        if (!profileResult) {
            return;
        }

        const user = profileResult.user;

        if (!user) {
            throw new Error("Your account information was not returned.");
        }

        const role = String(user.role || "").toUpperCase();

        if (role && role !== "LEARNER") {
            showMessage(
                "This dashboard is for current learners. Please use the correct portal.",
                "error"
            );
            return;
        }

        const [requestsResult, donationsResult] =
            await Promise.all([
                apiGet("/api/requests"),
                apiGet("/api/donations")
            ]);

        if (!requestsResult || !donationsResult) {
            return;
        }

        const requests = Array.isArray(requestsResult.requests)
            ? requestsResult.requests
            : [];

        const donations = Array.isArray(donationsResult.donations)
            ? donationsResult.donations
            : [];

        renderUser(user);
        renderStatistics(requests, donations);
        renderAvailableDonations(donations);
        renderRecentRequests(requests);
        renderProfile(user);

        showMessage("Your dashboard is up to date.", "success");
    } catch (error) {
        console.error("LOAD DASHBOARD ERROR:", error);

        showMessage(
            error.message || "Unable to load your dashboard.",
            "error"
        );

        renderAvailableDonations([]);
        renderRecentRequests([]);
    }
}

/* =====================================================
   GENERAL HELPERS
===================================================== */

function getValue(record, ...keys) {
    for (const key of keys) {
        if (
            record &&
            record[key] !== undefined &&
            record[key] !== null &&
            record[key] !== ""
        ) {
            return record[key];
        }
    }

    return "";
}

function setText(id, value, fallback = "—") {
    const element = document.getElementById(id);

    if (element) {
        element.textContent =
            value === null || value === undefined || value === ""
                ? fallback
                : String(value);
    }
}

function showMessage(message, type = "info") {
    const element = document.getElementById("dashboardMessage");

    if (!element) {
        console.log(message);
        return;
    }

    element.textContent = message;
    element.classList.add("show");

    element.classList.remove("success", "error", "info");
    element.classList.add(type);
}

function escapeHtml(value) {
    return String(value ?? "")
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");
}

function formatRole(role) {
    switch (String(role || "").toUpperCase()) {
        case "LEARNER":
            return "Current Learner";

        case "FORMER_LEARNER":
            return "Former Learner";

        case "COORDINATOR":
            return "Donation Coordinator";

        case "ADMIN":
            return "Administrator";

        default:
            return role || "User";
    }
}

/* =====================================================
   USER INFORMATION
===================================================== */

function renderUser(user) {
    const firstName = getValue(user, "firstName", "FIRSTNAME");
    const lastName = getValue(user, "lastName", "LASTNAME");
    const username = getValue(user, "username", "USERNAME");

    const fullName =
        [firstName, lastName].filter(Boolean).join(" ") ||
        username ||
        "Learner";

    setText("welcomeName", firstName || "Learner");
    setText("sidebarUserName", fullName);

    const initials = [firstName, lastName]
        .filter(Boolean)
        .map(name => String(name).charAt(0))
        .join("")
        .toUpperCase();

    setText("userInitials", initials || "L");
}

/* =====================================================
   DASHBOARD STATISTICS
===================================================== */

function renderStatistics(requests, donations) {
    const pending = requests.filter(request =>
        String(getValue(request, "STATUS", "status"))
            .toUpperCase() === "PENDING"
    ).length;

    const approved = requests.filter(request =>
        String(getValue(request, "STATUS", "status"))
            .toUpperCase() === "APPROVED"
    ).length;

    const availableQuantity = donations.reduce(
        (total, donation) => {
            const status = String(
                getValue(donation, "CONFIRMATION", "STATUS", "status")
            ).toUpperCase();

            if (
                status &&
                !["RECEIVED", "PARTIAL"].includes(status)
            ) {
                return total;
            }

            return total + Number(
                getValue(donation, "QUANTITY", "quantity") || 0
            );
        },
        0
    );

    setText("pendingRequests", pending, "0");
    setText("approvedRequests", approved, "0");
    setText("availableItems", availableQuantity, "0");
}

/* =====================================================
   AVAILABLE DONATIONS
===================================================== */

function renderAvailableDonations(donations) {
    const container = document.getElementById("availableItemsList");

    if (!container) {
        return;
    }

    const availableDonations = donations.filter(donation => {
        const status = String(
            getValue(donation, "CONFIRMATION", "STATUS", "status")
        ).toUpperCase();

        return !status || ["RECEIVED", "PARTIAL"].includes(status);
    });

    if (availableDonations.length === 0) {
        container.innerHTML = `
            <div class="empty-state">
                No items are currently available.
            </div>
        `;
        return;
    }

    container.innerHTML = availableDonations
        .slice(0, 5)
        .map(donation => {
            const itemName = getValue(
                donation,
                "ITEM_NAME",
                "ITEMNAME",
                "ITEM",
                "itemName",
                "UNIFORM_TYPE",
                "STATIONARY_TYPE"
            ) || "School Item";

            const category = getValue(
                donation,
                "CATEGORY",
                "ITEM_CATEGORY",
                "CATEGORY_NAME",
                "category"
            ) || "School item";

            const size = getValue(
                donation,
                "ITEM_SIZE",
                "ITEMSIZE",
                "SIZE",
                "size"
            ) || "Not specified";

            const condition = getValue(
                donation,
                "CONDITION",
                "ITEMCONDITION",
                "condition"
            ) || "Not specified";

            const quantity = Number(
                getValue(donation, "QUANTITY", "quantity") || 0
            );

            return `
                <div class="dashboard-list-item">
                    <div>
                        <div class="item-title">
                            ${escapeHtml(itemName)}
                        </div>

                        <div class="item-meta">
                            ${escapeHtml(category)}
                            &middot; Size:
                            ${escapeHtml(size)}
                            &middot; Condition:
                            ${escapeHtml(condition)}
                        </div>
                    </div>

                    <span class="status-badge">
                        ${quantity} available
                    </span>
                </div>
            `;
        })
        .join("");
}

/* =====================================================
   RECENT LEARNER REQUESTS
===================================================== */

function renderRecentRequests(requests) {
    const container = document.getElementById("recentRequestsList");

    if (!container) {
        return;
    }

    if (requests.length === 0) {
        container.innerHTML = `
            <div class="empty-state">
                You have not submitted any requests yet.
            </div>
        `;
        return;
    }

    container.innerHTML = requests
        .slice(0, 5)
        .map(request => {
            const item = getValue(
                request,
                "UNIFORM_TYPE",
                "STATIONARY_TYPE",
                "ITEM_NAME",
                "ITEM_CATEGORY",
                "CATEGORY_NAME",
                "itemName"
            ) || "Requested Item";

            const size = getValue(
                request,
                "ITEMSIZE",
                "ITEM_SIZE",
                "SIZE",
                "size"
            ) || "Not specified";

            const status = getValue(
                request,
                "STATUS",
                "status"
            ) || "PENDING";

            const quantity = Number(
                getValue(request, "QUANTITY", "quantity") || 0
            );

            return `
                <div class="dashboard-list-item">
                    <div>
                        <div class="item-title">
                            ${escapeHtml(item)}
                        </div>

                        <div class="item-meta">
                            Size: ${escapeHtml(size)}
                            &middot; Quantity: ${quantity}
                        </div>
                    </div>

                    <span class="status-badge">
                        ${escapeHtml(status)}
                    </span>
                </div>
            `;
        })
        .join("");
}

/* =====================================================
   PROFILE INFORMATION
===================================================== */

function renderProfile(user) {
    const container = document.getElementById("profileInformation");

    if (!container) {
        return;
    }

    const fields = [
        {
            label: "First Name",
            value: getValue(user, "firstName", "FIRSTNAME")
        },
        {
            label: "Last Name",
            value: getValue(user, "lastName", "LASTNAME")
        },
        {
            label: "Username",
            value: getValue(user, "username", "USERNAME")
        },
        {
            label: "Email",
            value: getValue(user, "email", "EMAIL")
        },
        {
            label: "Phone",
            value: getValue(user, "phone", "PHONENO", "PHONE") ||
                "Not provided"
        },
        {
            label: "Gender",
            value: getValue(user, "gender", "GENDER") ||
                "Not provided"
        },
        {
            label: "Grade",
            value: getValue(user, "grade", "GRADE") ||
                "Not provided"
        },
        {
            label: "School",
            value: getValue(user, "schoolName", "SCHOOLNAME") ||
                "Not provided"
        },
        {
            label: "Role",
            value: formatRole(getValue(user, "role", "ROLE"))
        }
    ];

    container.innerHTML = fields
        .map(field => `
            <div class="profile-field">
                <div class="profile-field-label">
                    ${escapeHtml(field.label)}
                </div>

                <div class="profile-field-value">
                    ${escapeHtml(field.value)}
                </div>
            </div>
        `)
        .join("");
}

/* =====================================================
   MOBILE NAVIGATION
===================================================== */

function initializeMobileMenu() {
    const button =
        document.getElementById("mobileMenuButton") ||
        document.getElementById("dashboardMenuButton");

    const navigation =
        document.getElementById("mainNavigation") ||
        document.getElementById("dashboardSidebar");

    if (!button || !navigation) {
        return;
    }

    button.setAttribute("aria-expanded", "false");

    button.addEventListener("click", () => {
        const isOpen = navigation.classList.toggle("open");

        button.setAttribute("aria-expanded", String(isOpen));
    });
}

/* =====================================================
   LOGOUT
===================================================== */

function initializeLogout() {
    const button =
        document.getElementById("logoutButton") ||
        document.getElementById("logoutBtn");

    if (!button) {
        return;
    }

    button.addEventListener("click", logout);
}
