"use strict";

const API_BASE_URL = "http://localhost:3000";
const AUTH_TOKEN_KEY = "edudonate_token";
const AUTH_USER_KEY = "edudonate_user";

/* =========================================
   GENERAL HELPERS
========================================= */

function getElementByIds(...ids) {
    for (const id of ids) {
        const element = document.getElementById(id);
        if (element) return element;
    }
    return null;
}

function getInputValue(...ids) {
    const element = getElementByIds(...ids);
    return element && "value" in element ? element.value : "";
}

function showMessage(element, text, type = "error") {
    if (!element) return;
    element.textContent = text;
    element.className = `form-message show ${type}`;
    element.setAttribute("role", "alert");
}

function clearMessage(element) {
    if (!element) return;
    element.textContent = "";
    element.className = "form-message";
}

async function readJsonResponse(response) {
    try {
        return await response.json();
    } catch (error) {
        throw new Error("The server returned an invalid response.");
    }
}

/* =========================================
   STORE AUTHENTICATION
========================================= */

function storeAuthentication(token, user, rememberMe = false) {
    clearAuthentication();

    const storage = rememberMe ? localStorage : sessionStorage;

    storage.setItem(AUTH_TOKEN_KEY, token);
    storage.setItem(AUTH_USER_KEY, JSON.stringify(user));
}

function getAuthToken() {
    return (
        sessionStorage.getItem(AUTH_TOKEN_KEY) ||
        localStorage.getItem(AUTH_TOKEN_KEY)
    );
}

function getStoredUser() {
    const userData =
        sessionStorage.getItem(AUTH_USER_KEY) ||
        localStorage.getItem(AUTH_USER_KEY);

    if (!userData) return null;

    try {
        return JSON.parse(userData);
    } catch (error) {
        console.error("Unable to read stored user:", error);
        clearAuthentication();
        return null;
    }
}

function clearAuthentication() {
    sessionStorage.removeItem(AUTH_TOKEN_KEY);
    sessionStorage.removeItem(AUTH_USER_KEY);
    localStorage.removeItem(AUTH_TOKEN_KEY);
    localStorage.removeItem(AUTH_USER_KEY);
}

function logout() {
    clearAuthentication();
    window.location.href = "/pages/login.html";
}

function formatRole(role) {
    const normalizedRole = String(role || "").trim().toUpperCase();

    switch (normalizedRole) {
        case "LEARNER":
            return "Current Learner";
        case "FORMER_LEARNER":
            return "Former Learner";
        case "COORDINATOR":
            return "Coordinator";
        case "ADMIN":
            return "Administrator";
        default:
            return normalizedRole || "User";
    }
}

/* =========================================
   DASHBOARD REDIRECTION
========================================= */

function getDashboardUrl(role) {
    switch (String(role || "").trim().toUpperCase()) {
        case "LEARNER":
            return "/pages/learner/dashboard.html";
        case "FORMER_LEARNER":
            return "/pages/former-learner/dashboard.html";
        case "COORDINATOR":
            return "/pages/Coordinator/dashboard.html";
        case "ADMIN":
            return "/pages/admin/dashboard.html";
        default:
            return "";
    }
}

/* =========================================
   LOGIN
   POST /api/auth/login
========================================= */

function initializeLogin() {
    const form = document.getElementById("loginForm");

    if (!form || form.dataset.loginInitialized === "true") {
        return;
    }

    form.dataset.loginInitialized = "true";

    form.addEventListener("submit", async (event) => {
        event.preventDefault();

        const usernameInput = getElementByIds(
            "loginUsername",
            "username"
        );

        const passwordInput = getElementByIds(
            "loginPassword",
            "password"
        );

        const message = document.getElementById("loginMessage");
        const rememberMe = document.getElementById("rememberMe");

        const username = usernameInput
            ? usernameInput.value.trim()
            : "";

        const password = passwordInput
            ? passwordInput.value
            : "";

        clearMessage(message);

        if (!username) {
            showMessage(message, "Email or username is required.", "error");
            usernameInput?.focus();
            return;
        }

        if (!password) {
            showMessage(message, "Password is required.", "error");
            passwordInput?.focus();
            return;
        }

        const submitButton = form.querySelector('button[type="submit"]');
        const originalButtonText = submitButton
            ? submitButton.innerHTML
            : "";

        if (submitButton) {
            submitButton.disabled = true;
            submitButton.innerHTML = "Signing In...";
        }

        try {
            const response = await fetch(
                `${API_BASE_URL}/api/auth/login`,
                {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify({
                        username,
                        password
                    })
                }
            );

            const result = await readJsonResponse(response);

            if (!response.ok || !result.success) {
                showMessage(
                    message,
                    result.message ||
                        "Login failed. Please check your details.",
                    "error"
                );
                return;
            }

            if (!result.token || !result.user) {
                throw new Error(
                    "The login response did not include a token and user account."
                );
            }

            storeAuthentication(
                result.token,
                result.user,
                Boolean(rememberMe && rememberMe.checked)
            );

            const dashboardUrl = getDashboardUrl(result.user.role);

            if (!dashboardUrl) {
                showMessage(
                    message,
                    `Login succeeded, but no dashboard is configured for ${formatRole(result.user.role)}.`,
                    "error"
                );
                return;
            }

            showMessage(
                message,
                "Login successful. Opening your dashboard...",
                "success"
            );

            window.setTimeout(() => {
                window.location.assign(dashboardUrl);
            }, 500);
        } catch (error) {
            console.error("LOGIN ERROR:", error);

            showMessage(
                message,
                error.message &&
                error.message.includes("invalid response")
                    ? error.message
                    : "Unable to connect to EduDonate. Check that the backend is running and try again.",
                "error"
            );
        } finally {
            if (submitButton) {
                submitButton.disabled = false;
                submitButton.innerHTML = originalButtonText;
            }
        }
    });
}

/* =========================================
   REGISTRATION
   POST /api/auth/register
========================================= */

function initializeRegistration() {
    const form = getElementByIds(
        "registerForm",
        "registrationForm"
    );

    if (
        !form ||
        form.dataset.registrationInitialized === "true"
    ) {
        return;
    }

    form.dataset.registrationInitialized = "true";

    const learnerDetailsSection =
        document.getElementById("learnerDetailsSection");

    const currentLearnerFields =
        document.getElementById("currentLearnerFields");

    const formerLearnerFields =
        document.getElementById("formerLearnerFields");

    const currentGradeInput =
        document.getElementById("currentGrade");

    const formerGradeInput =
        document.getElementById("formerGrade");

    const leaveDateInput =
        document.getElementById("leaveDate");

    if (leaveDateInput) {
        const today = new Date();
        const year = today.getFullYear();
        const month = String(today.getMonth() + 1).padStart(2, "0");
        const day = String(today.getDate()).padStart(2, "0");

        leaveDateInput.max = `${year}-${month}-${day}`;
    }

    function updateRoleSpecificFields() {
        const checkedRole = document.querySelector(
            'input[name="role"]:checked'
        );

        const selectedRoleValue = checkedRole
            ? checkedRole.value
            : "";

        const isCurrentLearner =
            selectedRoleValue === "LEARNER";

        const isFormerLearner =
            selectedRoleValue === "FORMER_LEARNER";

        if (learnerDetailsSection) {
            learnerDetailsSection.hidden = !selectedRoleValue;
        }

        if (currentLearnerFields) {
            currentLearnerFields.hidden = !isCurrentLearner;
        }

        if (formerLearnerFields) {
            formerLearnerFields.hidden = !isFormerLearner;
        }

        if (currentGradeInput) {
            currentGradeInput.disabled = !isCurrentLearner;
            currentGradeInput.required = isCurrentLearner;
        }

        if (formerGradeInput) {
            formerGradeInput.disabled = !isFormerLearner;
            formerGradeInput.required = isFormerLearner;
        }

        if (leaveDateInput) {
            leaveDateInput.disabled = !isFormerLearner;
            leaveDateInput.required = isFormerLearner;
        }
    }

    document.querySelectorAll('input[name="role"]').forEach((radio) => {
        radio.addEventListener("change", updateRoleSpecificFields);
    });

    updateRoleSpecificFields();

    form.addEventListener("submit", async (event) => {
        event.preventDefault();

        const message = getElementByIds(
            "registerMessage",
            "registrationMessage"
        );

        clearMessage(message);

        const firstName = getInputValue("firstName").trim();
        const lastName = getInputValue("lastName").trim();
        const email = getInputValue("email").trim();
        const phone = getInputValue("phone").trim();
        const username = getInputValue("username").trim();
        const gender = getInputValue("gender");

        const password = getInputValue(
            "registerPassword",
            "password",
            "newPassword"
        );

        const confirmPassword = getInputValue(
            "confirmPassword",
            "confirmRegisterPassword"
        );

        const selectedRole = document.querySelector(
            'input[name="role"]:checked'
        );

        const terms = document.getElementById("terms");

        const role = selectedRole
            ? String(selectedRole.value).trim().toUpperCase()
            : "";

        const grade = role === "LEARNER"
            ? getInputValue("currentGrade")
            : getInputValue("formerGrade");

        const leaveDate = role === "FORMER_LEARNER"
            ? getInputValue("leaveDate")
            : "";

        if (
            !firstName ||
            !lastName ||
            !email ||
            !phone ||
            !username ||
            !password ||
            !confirmPassword
        ) {
            showMessage(message, "Please complete all required fields.", "error");
            return;
        }

        if (!selectedRole) {
            showMessage(
                message,
                "Please select Former Learner or Current Learner.",
                "error"
            );
            return;
        }

        if (terms && !terms.checked) {
            showMessage(
                message,
                "Please agree to use EduDonate responsibly.",
                "error"
            );
            return;
        }

        const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

        if (!emailPattern.test(email)) {
            showMessage(message, "Please enter a valid email address.", "error");
            return;
        }

        if (password.length < 8) {
            showMessage(
                message,
                "Password must contain at least 8 characters.",
                "error"
            );
            return;
        }

        if (password !== confirmPassword) {
            showMessage(message, "Passwords do not match.", "error");
            return;
        }

        if (!["LEARNER", "FORMER_LEARNER"].includes(role)) {
            showMessage(
                message,
                "Please select a valid learner account type.",
                "error"
            );
            return;
        }

        if (!grade) {
            showMessage(
                message,
                role === "FORMER_LEARNER"
                    ? "Please select the highest grade you completed."
                    : "Please select your current grade.",
                "error"
            );
            return;
        }

        if (role === "FORMER_LEARNER" && !leaveDate) {
            showMessage(
                message,
                "Please enter the date you left school.",
                "error"
            );
            return;
        }

        const submitButton = form.querySelector('button[type="submit"]');

        const originalButtonText = submitButton
            ? submitButton.innerHTML
            : "";

        if (submitButton) {
            submitButton.disabled = true;
            submitButton.innerHTML = "Creating Account...";
        }

        try {
            const response = await fetch(
                `${API_BASE_URL}/api/auth/register`,
                {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify({
                        firstName,
                        lastName,
                        email,
                        phone,
                        username,
                        gender: gender || null,
                        password,
                        role,
                        grade,
                        leaveDate: leaveDate || null
                    })
                }
            );

            const result = await readJsonResponse(response);

            if (!response.ok || !result.success) {
                showMessage(
                    message,
                    result.message || "Registration failed.",
                    "error"
                );
                return;
            }

            showMessage(
                message,
                result.message ||
                    "Registration successful. You can now sign in.",
                "success"
            );

            form.reset();
            updateRoleSpecificFields();

            window.setTimeout(() => {
                window.location.assign("/pages/login.html");
            }, 1200);
        } catch (error) {
            console.error("REGISTRATION ERROR:", error);

            showMessage(
                message,
                "Unable to connect to EduDonate. Check that the backend is running and try again.",
                "error"
            );
        } finally {
            if (submitButton) {
                submitButton.disabled = false;
                submitButton.innerHTML = originalButtonText;
            }
        }
    });
}

/* =========================================
   PASSWORD SHOW / HIDE BUTTONS
========================================= */

function initializePasswordToggles() {
    document.querySelectorAll("[data-target]").forEach((button) => {
        if (button.dataset.passwordToggleInitialized === "true") {
            return;
        }

        button.dataset.passwordToggleInitialized = "true";

        button.addEventListener("click", () => {
            const targetId = button.getAttribute("data-target");

            const input = targetId
                ? document.getElementById(targetId)
                : null;

            if (!input) return;

            const showingPassword = input.type === "password";

            input.type = showingPassword ? "text" : "password";

            button.textContent = showingPassword ? "Hide" : "Show";

            button.setAttribute(
                "aria-label",
                showingPassword ? "Hide password" : "Show password"
            );
        });
    });
}

/* =========================================
   INITIALIZE THE PAGE
========================================= */

document.addEventListener("DOMContentLoaded", () => {
    initializeLogin();
    initializeRegistration();
    initializePasswordToggles();
});

// Make helpers available to other frontend scripts.
window.getAuthToken = getAuthToken;
window.getStoredUser = getStoredUser;
window.storeAuthentication = storeAuthentication;
window.clearAuthentication = clearAuthentication;
window.logout = logout;
window.formatRole = formatRole;
window.showMessage = showMessage;
window.clearMessage = clearMessage;