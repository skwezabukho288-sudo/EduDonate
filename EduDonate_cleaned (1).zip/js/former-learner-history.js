
const FORMER_LEARNER_API = "http://localhost:3000";

let myDonations = [];

document.addEventListener("DOMContentLoaded", () => {
    document.getElementById("menuButton")
        .addEventListener("click", toggleMenu);

    document.getElementById("logoutButton")
        .addEventListener("click", logout);

    document.getElementById("refreshButton")
        .addEventListener("click", loadMyDonations);

    document.getElementById("searchInput")
        .addEventListener("input", renderDonations);

    document.getElementById("statusFilter")
        .addEventListener("change", renderDonations);

    loadMyDonations();
});

function getToken() {
    return (
        sessionStorage.getItem("edudonate_token") ||
        localStorage.getItem("edudonate_token")
    );
}

function getStoredUser() {
    const stored =
        sessionStorage.getItem("edudonate_user") ||
        localStorage.getItem("edudonate_user");

    try {
        return stored ? JSON.parse(stored) : null;
    } catch {
        return null;
    }
}

function logout() {
    sessionStorage.removeItem("edudonate_token");
    sessionStorage.removeItem("edudonate_user");
    localStorage.removeItem("edudonate_token");
    localStorage.removeItem("edudonate_user");

    window.location.href = "../login.html";
}

function toggleMenu() {
    const sidebar = document.getElementById("sidebar");
    const button = document.getElementById("menuButton");

    const isOpen = sidebar.classList.toggle("open");
    button.setAttribute("aria-expanded", String(isOpen));
}

function getValue(record, ...keys) {
    for (const key of keys) {
        if (
            record &&
            record[key] !== undefined &&
            record[key] !== null
        ) {
            return record[key];
        }
    }

    return "";
}

function showMessage(message, type = "info") {
    const element = document.getElementById("pageMessage");

    element.textContent = message;
    element.className = `message show ${type}`;
}

function setUserDetails(user) {
    const firstName = getValue(
        user,
        "firstName",
        "firstname",
        "FIRSTNAME"
    );

    const lastName = getValue(
        user,
        "lastName",
        "lastname",
        "LASTNAME"
    );

    const fullName =
        getValue(user, "fullName", "FULL_NAME") ||
        [firstName, lastName].filter(Boolean).join(" ") ||
        getValue(user, "username", "USERNAME") ||
        "Former Learner";

    document.getElementById("userName").textContent = fullName;

    document.getElementById("userInitials").textContent =
        fullName
            .trim()
            .split(/\s+/)
            .slice(0, 2)
            .map(part => part.charAt(0).toUpperCase())
            .join("") || "FL";
}

async function loadMyDonations() {
    const token = getToken();
    const user = getStoredUser();

    if (!token) {
        window.location.href = "../login.html";
        return;
    }

    const role = String(
        getValue(user, "role", "ROLE")
    ).toUpperCase();

    if (user && role !== "FORMER_LEARNER") {
        showMessage(
            "This page is only available to Former Learner accounts.",
            "error"
        );
        return;
    }

    setUserDetails(user);

    const refreshButton = document.getElementById("refreshButton");
    refreshButton.disabled = true;
    refreshButton.textContent = "Loading...";

    showMessage("Loading your donation records...");

    document.getElementById("donationsTableBody").innerHTML = `
        <tr>
            <td colspan="9" class="empty-state">
                Loading donation records...
            </td>
        </tr>`;

    try {
        const response = await fetch(
            `${FORMER_LEARNER_API}/api/donations`,
            {
                method: "GET",
                headers: {
                    Authorization: `Bearer ${token}`
                }
            }
        );

        const result = await response.json().catch(() => ({}));

        if (response.status === 401) {
            logout();
            return;
        }

        if (!response.ok || result.success === false) {
            throw new Error(
                result.message ||
                "Unable to retrieve your donations."
            );
        }

        myDonations = Array.isArray(result.donations)
            ? result.donations
            : [];

        updateStatistics();
        renderDonations();

        showMessage(
            `Loaded ${myDonations.length} donation record(s).`,
            "success"
        );

    } catch (error) {
        console.error("Load my donations error:", error);

        showMessage(
            error.message ||
            "Unable to load donations. Check the server and try again.",
            "error"
        );

        ["totalDonations", "totalItems", "pendingDonations"]
            .forEach(id => {
                document.getElementById(id).textContent = "—";
            });

        document.getElementById("donationsTableBody").innerHTML = `
            <tr>
                <td colspan="9" class="empty-state">
                    Could not load donation records. Please try Refresh.
                </td>
            </tr>`;

    } finally {
        refreshButton.disabled = false;
        refreshButton.textContent = "Refresh";
    }
}

function getDonationStatus(donation) {
    return String(
        getValue(
            donation,
            "CONFIRMATION",
            "STATUS",
            "DONATION_STATUS",
            "status"
        ) || "UNKNOWN"
    ).trim().toUpperCase();
}

function getDonationQuantity(donation) {
    return Number(
        getValue(donation, "QUANTITY", "quantity")
    ) || 0;
}

function updateStatistics() {
    const pendingCount = myDonations.filter(donation =>
        getDonationStatus(donation) === "PENDING"
    ).length;

    const itemCount = myDonations.reduce(
        (total, donation) =>
            total + getDonationQuantity(donation),
        0
    );

    document.getElementById("totalDonations").textContent =
        myDonations.length;

    document.getElementById("totalItems").textContent =
        itemCount;

    document.getElementById("pendingDonations").textContent =
        pendingCount;
}

function getDonationDate(donation) {
    return getValue(
        donation,
        "DONATIONDATE",
        "DONATION_DATE",
        "DATE_CREATED",
        "CREATED_AT"
    );
}

function formatDonationDate(value) {
    if (!value) return "—";

    const date = new Date(value);

    if (Number.isNaN(date.getTime())) {
        return String(value);
    }

    return date.toLocaleDateString("en-ZA");
}

function renderDonations() {
    const tbody = document.getElementById("donationsTableBody");

    const search = document.getElementById("searchInput")
        .value.trim().toLowerCase();

    const selectedStatus =
        document.getElementById("statusFilter").value;

    const filtered = myDonations.filter(donation => {
        const id = getValue(
            donation,
            "DONATIONID",
            "DONATION_ID"
        );

        const item = getValue(
            donation,
            "ITEM_NAME",
            "ITEMNAME",
            "ITEM"
        );

        const category = getValue(
            donation,
            "ITEM_CATEGORY",
            "CATEGORY",
            "ITEM_TYPE"
        );

        const status = getDonationStatus(donation);

        const searchableText =
            `${id} ${item} ${category} ${status}`.toLowerCase();

        return (
            searchableText.includes(search) &&
            (!selectedStatus || status === selectedStatus)
        );
    });

    if (filtered.length === 0) {
        const emptyText = myDonations.length === 0
            ? "You have not submitted any donations yet. Use Donate Item to get started."
            : "No donations match your search or selected status.";

        tbody.innerHTML = `
            <tr>
                <td colspan="9" class="empty-state">
                    ${escapeHTML(emptyText)}
                </td>
            </tr>`;
        return;
    }

    tbody.innerHTML = filtered.map(donation => {
        const id = getValue(
            donation,
            "DONATIONID",
            "DONATION_ID"
        ) || "—";

        const date = formatDonationDate(
            getDonationDate(donation)
        );

        const item = getValue(
            donation,
            "ITEM_NAME",
            "ITEMNAME",
            "ITEM"
        ) || "—";

        const category = getValue(
            donation,
            "ITEM_CATEGORY",
            "CATEGORY",
            "ITEM_TYPE"
        ) || "—";

        const size = getValue(
            donation,
            "ITEM_SIZE",
            "ITEMSIZE",
            "SIZE_NAME"
        ) || "—";

        const condition = getValue(
            donation,
            "CONDITION",
            "ITEM_CONDITION"
        ) || "—";

        const quantity = getDonationQuantity(donation);

        const school = getValue(
            donation,
            "SCHOOLNAME",
            "SCHOOL_NAME",
            "SCHOOL"
        ) || "—";

        const status = getDonationStatus(donation);
        const statusClass = [
            "pending",
            "received",
            "partial",
            "distributed",
            "completed",
            "rejected"
        ].includes(status.toLowerCase())
            ? status.toLowerCase()
            : "";

        return `
            <tr>
                <td>${escapeHTML(id)}</td>
                <td>${escapeHTML(date)}</td>
                <td>${escapeHTML(item)}</td>
                <td>${escapeHTML(category)}</td>
                <td>${escapeHTML(size)}</td>
                <td>${escapeHTML(condition)}</td>
                <td>${escapeHTML(quantity)}</td>
                <td>${escapeHTML(school)}</td>
                <td>
                    <span class="status-badge ${escapeHTML(statusClass)}">
                        ${escapeHTML(status)}
                    </span>
                </td>
            </tr>`;
    }).join("");
}

function escapeHTML(value) {
    return String(value ?? "").replace(/[&<>"']/g, character => ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#39;"
    })[character]);
}
