
"use strict";

const DISTRIBUTIONS_API = "http://localhost:3000";

let allDistributions = [];
let formRequests = [];
let formDonations = [];

document.addEventListener("DOMContentLoaded", () => {
    const bind = (id, eventName, handler) => {
        const element = document.getElementById(id);
        if (element) element.addEventListener(eventName, handler);
    };

    bind("searchInput", "input", renderDistributions);
    bind("statusFilter", "change", renderDistributions);
    bind("refreshBtn", "click", loadPageData);
    bind("logoutBtn", "click", logout);

    // Mobile menu
    const menuButton = document.getElementById("dashboardMenuButton");
    const sidebar = document.getElementById("dashboardSidebar");

    if (menuButton && sidebar) {
        menuButton.addEventListener("click", () => {
            const isOpen = sidebar.classList.toggle("open");
            menuButton.setAttribute("aria-expanded", String(isOpen));
        });
    }

    bind("requestSelect", "change", () => {
        const donationSelect = document.getElementById("donationSelect");
        const quantityInput = document.getElementById("distributionQuantity");

        if (donationSelect) donationSelect.value = "";
        if (quantityInput) quantityInput.value = "";

        populateDonationOptions();
        updateQuantityLimit();
    });

    bind("donationSelect", "change", () => {
        const quantityInput = document.getElementById("distributionQuantity");

        if (quantityInput) quantityInput.value = "";

        updateQuantityLimit();
    });

    bind("distributionForm", "submit", recordDistribution);

    loadPageData();
});

/* =========================================
   AUTHENTICATION AND HELPERS
========================================= */

function getToken() {
    return (
        sessionStorage.getItem("edudonate_token") ||
        localStorage.getItem("edudonate_token")
    );
}

function getStoredUser() {
    const stored =
        sessionStorage.getItem("edudonate_user") ||
        localStorage.getItem("edudonate_user");

    try {
        return stored ? JSON.parse(stored) : null;
    } catch {
        return null;
    }
}

function logout() {
    sessionStorage.removeItem("edudonate_token");
    sessionStorage.removeItem("edudonate_user");

    localStorage.removeItem("edudonate_token");
    localStorage.removeItem("edudonate_user");

    window.location.href = "../login.html";
}

function getValue(record, ...keys) {
    if (!record) return "";

    for (const key of keys) {
        if (record[key] !== undefined && record[key] !== null) {
            return record[key];
        }
    }

    return "";
}

function extractRecords(result, ...keys) {
    if (Array.isArray(result)) return result;

    for (const key of keys) {
        if (Array.isArray(result?.[key])) {
            return result[key];
        }
    }

    if (Array.isArray(result?.data)) return result.data;
    if (Array.isArray(result?.rows)) return result.rows;

    return [];
}

function getRecordId(record, ...keys) {
    return String(getValue(record, ...keys));
}

function getDistributionStatus(record) {
    return String(
        getValue(
            record,
            "CONFIRMATION",
            "STATUS",
            "DISTRIBUTION_STATUS",
            "status"
        ) || "UNKNOWN"
    ).trim().toUpperCase();
}

function isCompletedDistribution(record) {
    return ["DISTRIBUTED", "COMPLETED"].includes(
        getDistributionStatus(record)
    );
}

async function apiGet(path, token) {
    const response = await fetch(`${DISTRIBUTIONS_API}${path}`, {
        method: "GET",
        headers: {
            Authorization: `Bearer ${token}`
        }
    });

    const result = await response.json().catch(() => ({}));

    if (response.status === 401) {
        logout();
        throw new Error("Your session has expired. Please log in again.");
    }

    if (!response.ok || result.success === false) {
        throw new Error(result.message || `Unable to load ${path}.`);
    }

    return result;
}

/* =========================================
   LOAD PAGE DATA
========================================= */

async function loadPageData() {
    await loadDistributions();
    await loadDistributionFormData();
}

async function loadDistributions() {
    const message = document.getElementById("pageMessage");
    const tbody = document.getElementById("distributionsTableBody");
    const token = getToken();

    if (!token) {
        logout();
        return;
    }

    if (message) {
        message.textContent = "Loading distribution records...";
        message.classList.add("show");
    }

    if (tbody) {
        tbody.innerHTML = `
            <tr>
                <td colspan="8" class="empty-state">
                    Loading distribution records...
                </td>
            </tr>`;
    }

    try {
        const result = await apiGet("/api/distributions", token);
        const user = getStoredUser();

        if (
            user &&
            String(user.role || user.ROLE || "").toUpperCase() !==
                "COORDINATOR"
        ) {
            throw new Error(
                "This page is only available to Donation Coordinators."
            );
        }

        const coordinatorName = document.getElementById("coordinatorName");

        if (coordinatorName) {
            coordinatorName.textContent =
                user?.firstName ||
                user?.firstname ||
                user?.FIRSTNAME ||
                user?.username ||
                user?.USERNAME ||
                "Donation Coordinator";
        }

        allDistributions = extractRecords(result, "distributions");

        updateDistributionSummary();
        renderDistributions();

        if (message) {
            message.textContent =
                `Loaded ${allDistributions.length} distribution record(s).`;
        }
    } catch (error) {
        console.error("Load distributions error:", error);

        if (message) {
            message.textContent =
                error.message || "Unable to load distribution records.";
        }

        if (tbody) {
            tbody.innerHTML = `
                <tr>
                    <td colspan="8" class="empty-state">
                        Could not load distributions. Check the server and try Refresh.
                    </td>
                </tr>`;
        }

        [
            "totalCount",
            "distributedQuantity",
            "itemsDistributed",
            "completedCount",
            "pendingCount"
        ].forEach(id => {
            const element = document.getElementById(id);
            if (element) element.textContent = "—";
        });
    }
}

async function loadDistributionFormData() {
    const token = getToken();

    if (!token) {
        logout();
        return;
    }

    try {
        const [requestsResult, donationsResult] = await Promise.all([
            apiGet("/api/requests", token),
            apiGet("/api/donations", token)
        ]);

        formRequests = extractRecords(requestsResult, "requests");
        formDonations = extractRecords(donationsResult, "donations");

        populateRequestOptions();
    } catch (error) {
        console.error("Load distribution form data error:", error);

        const requestSelect = document.getElementById("requestSelect");
        const donationSelect = document.getElementById("donationSelect");

        if (requestSelect) {
            requestSelect.innerHTML =
                '<option value="">Could not load requests</option>';
            requestSelect.disabled = true;
        }

        if (donationSelect) {
            donationSelect.innerHTML =
                '<option value="">Could not load donations</option>';
            donationSelect.disabled = true;
        }

        showFormMessage(
            error.message || "Unable to load requests and donations.",
            "error"
        );
    }
}

/* =========================================
   QUANTITY CALCULATIONS
========================================= */

function getDistributedForRequest(requestId) {
    return allDistributions.reduce((total, record) => {
        const recordRequestId = getRecordId(
            record,
            "REQUESTID",
            "REQUEST_ID",
            "requestId"
        );

        if (
            recordRequestId === String(requestId) &&
            isCompletedDistribution(record)
        ) {
            return total +
                (Number(getValue(record, "QUANTITY", "quantity")) || 0);
        }

        return total;
    }, 0);
}

function getDistributedFromDonation(donationId) {
    return allDistributions.reduce((total, record) => {
        const recordDonationId = getRecordId(
            record,
            "DONATIONID",
            "DONATION_ID",
            "donationId"
        );

        if (
            recordDonationId === String(donationId) &&
            isCompletedDistribution(record)
        ) {
            return total +
                (Number(getValue(record, "QUANTITY", "quantity")) || 0);
        }

        return total;
    }, 0);
}

function getRemainingRequestQuantity(request) {
    const requestId = getRecordId(
        request,
        "REQUESTID",
        "REQUEST_ID",
        "requestId",
        "id"
    );

    const requestedQuantity =
        Number(getValue(request, "QUANTITY", "quantity")) || 0;

    return Math.max(
        0,
        requestedQuantity - getDistributedForRequest(requestId)
    );
}

function getRemainingDonationQuantity(donation) {
    const donationId = getRecordId(
        donation,
        "DONATIONID",
        "DONATION_ID",
        "donationId",
        "id"
    );

    const donatedQuantity =
        Number(getValue(donation, "QUANTITY", "quantity")) || 0;

    return Math.max(
        0,
        donatedQuantity - getDistributedFromDonation(donationId)
    );
}

/* =========================================
   REQUEST AND DONATION DETAILS
========================================= */

function getRequestStatus(request) {
    return String(
        getValue(request, "STATUS", "REQUEST_STATUS", "status")
    ).trim().toUpperCase();
}

function getDonationStatus(donation) {
    return String(
        getValue(
            donation,
            "CONFIRMATION",
            "STATUS",
            "DONATION_STATUS",
            "status"
        )
    ).trim().toUpperCase();
}

function getRequestId(request) {
    return getRecordId(
        request,
        "REQUESTID",
        "REQUEST_ID",
        "requestId",
        "id"
    );
}

function getDonationId(donation) {
    return getRecordId(
        donation,
        "DONATIONID",
        "DONATION_ID",
        "donationId",
        "id"
    );
}

function getRequestItemName(request) {
    return getValue(
        request,
        "ITEM_NAME",
        "UNIFORM_TYPE",
        "STATIONARY_TYPE",
        "STATIONERY_TYPE",
        "ITEM_TYPE",
        "PRODUCT_NAME",
        "CATEGORY_NAME",
        "CATEGORY"
    ) || "Requested item";
}

function getDonationItemName(donation) {
    return getValue(
        donation,
        "ITEM_NAME",
        "UNIFORM_TYPE",
        "STATIONARY_TYPE",
        "STATIONERY_TYPE",
        "ITEM_TYPE",
        "PRODUCT_NAME",
        "CATEGORY_NAME",
        "CATEGORY"
    ) || "Donated item";
}

function sameDimension(
    first,
    second,
    idKeys,
    labelKeys,
    allowBothBlank = false
) {
    const firstId = getValue(first, ...idKeys);
    const secondId = getValue(second, ...idKeys);

    if (
        firstId !== "" &&
        firstId !== null &&
        secondId !== "" &&
        secondId !== null
    ) {
        return String(firstId) === String(secondId);
    }

    const firstLabel = String(
        getValue(first, ...labelKeys) || ""
    ).trim().toLowerCase();

    const secondLabel = String(
        getValue(second, ...labelKeys) || ""
    ).trim().toLowerCase();

    if (firstLabel && secondLabel) {
        return firstLabel === secondLabel;
    }

    return (
        allowBothBlank &&
        !firstLabel &&
        !secondLabel &&
        !firstId &&
        !secondId
    );
}

function isDonationMatchingRequest(donation, request) {
    if (!donation || !request) return false;

    const categoryMatches = sameDimension(
        donation,
        request,
        ["CAID", "CATEGORYID", "CATEGORY_ID", "CATID"],
        ["CATEGORY_NAME", "CATEGORY", "CATEGORYNAME", "ITEM_CATEGORY"]
    );

    const sizeMatches = sameDimension(
        donation,
        request,
        ["ITSID", "ITEMSIZEID", "ITEM_SIZE_ID", "SIZEID", "SIZE_ID"],
        ["ITEM_SIZE", "SIZE_NAME", "SIZE", "ITEMSIZE"],
        true
    );

    return categoryMatches && sizeMatches;
}

/* =========================================
   FORM DROPDOWNS
========================================= */

function populateRequestOptions() {
    const select = document.getElementById("requestSelect");
    if (!select) return;

    const currentId = select.value;

    const approvedRequests = formRequests.filter(request =>
        getRequestStatus(request) === "APPROVED" &&
        getRequestId(request) &&
        getRemainingRequestQuantity(request) > 0
    );

    select.innerHTML =
        '<option value="">Select an approved request...</option>';

    approvedRequests.forEach(request => {
        const requestId = getRequestId(request);
        const remaining = getRemainingRequestQuantity(request);
        const itemName = getRequestItemName(request);

        const option = document.createElement("option");
        option.value = requestId;
        option.textContent =
            `Request #${requestId} - ${itemName} (${remaining} remaining)`;

        select.appendChild(option);
    });

    select.disabled = approvedRequests.length === 0;

    if (approvedRequests.length === 0) {
        select.innerHTML =
            '<option value="">No approved requests with remaining quantities</option>';
    } else if (
        approvedRequests.some(request => getRequestId(request) === currentId)
    ) {
        select.value = currentId;
    }

    populateDonationOptions();
    updateQuantityLimit();
}

function populateDonationOptions() {
    const requestSelect = document.getElementById("requestSelect");
    const donationSelect = document.getElementById("donationSelect");

    if (!requestSelect || !donationSelect) return;

    const request = formRequests.find(
        item => getRequestId(item) === requestSelect.value
    );

    const previousDonationId = donationSelect.value;

    donationSelect.innerHTML =
        '<option value="">Select a matching donation...</option>';

    if (!request) {
        donationSelect.innerHTML =
            '<option value="">Select a request first</option>';
        donationSelect.disabled = true;
        return;
    }

    const availableDonations = formDonations.filter(donation => {
        return (
            getDonationId(donation) &&
            ["RECEIVED", "PARTIAL"].includes(getDonationStatus(donation)) &&
            getRemainingDonationQuantity(donation) > 0 &&
            isDonationMatchingRequest(donation, request)
        );
    });

    if (availableDonations.length === 0) {
        donationSelect.innerHTML =
            '<option value="">No matching donations with available stock</option>';
        donationSelect.disabled = true;
        return;
    }

    availableDonations.forEach(donation => {
        const donationId = getDonationId(donation);
        const remaining = getRemainingDonationQuantity(donation);
        const itemName = getDonationItemName(donation);

        const option = document.createElement("option");
        option.value = donationId;
        option.textContent =
            `Donation #${donationId} — ${itemName} (available: ${remaining})`;

        donationSelect.appendChild(option);
    });

    donationSelect.disabled = false;

    if (
        availableDonations.some(
            donation => getDonationId(donation) === previousDonationId
        )
    ) {
        donationSelect.value = previousDonationId;
    }
}

function updateQuantityLimit() {
    const requestSelect = document.getElementById("requestSelect");
    const donationSelect = document.getElementById("donationSelect");
    const quantityInput = document.getElementById("distributionQuantity");
    const quantityHelp = document.getElementById("quantityHelp");

    if (!requestSelect || !donationSelect || !quantityInput) return;

    const request = formRequests.find(
        item => getRequestId(item) === requestSelect.value
    );

    const donation = formDonations.find(
        item => getDonationId(item) === donationSelect.value
    );

    if (
        !request ||
        !donation ||
        !isDonationMatchingRequest(donation, request)
    ) {
        quantityInput.removeAttribute("max");

        if (quantityHelp) {
            quantityHelp.textContent =
                "Select a matching request and donation first.";
        }

        return;
    }

    const requestRemaining = getRemainingRequestQuantity(request);
    const donationRemaining = getRemainingDonationQuantity(donation);
    const maximum = Math.min(requestRemaining, donationRemaining);

    quantityInput.max = String(maximum);

    if (quantityHelp) {
        quantityHelp.textContent =
            `You can distribute up to ${maximum} item(s). ` +
            `Request remaining: ${requestRemaining}; ` +
            `donation available: ${donationRemaining}.`;
    }

    if (
        quantityInput.value &&
        Number(quantityInput.value) > maximum
    ) {
        quantityInput.value = String(maximum);
    }
}

function showFormMessage(message, type = "") {
    const element = document.getElementById("distributionFormMessage");
    if (!element) return;

    element.className = "dashboard-message show";

    if (type) element.classList.add(type);

    element.textContent = message;
}

/* =========================================
   RECORD A DISTRIBUTION
========================================= */

async function recordDistribution(event) {
    event.preventDefault();

    const token = getToken();

    if (!token) {
        logout();
        return;
    }

    const requestId = document.getElementById("requestSelect").value;
    const donationId = document.getElementById("donationSelect").value;
    const quantityInput = document.getElementById("distributionQuantity");
    const quantity = Number(quantityInput.value);

    const commentsInput = document.getElementById("distributionComments");
    const comments = commentsInput ? commentsInput.value.trim() : "";

    const request = formRequests.find(
        item => getRequestId(item) === requestId
    );

    const donation = formDonations.find(
        item => getDonationId(item) === donationId
    );

    if (!request || !donation) {
        showFormMessage(
            "Please select an approved request and an available donation.",
            "error"
        );
        return;
    }

    if (getRequestStatus(request) !== "APPROVED") {
        showFormMessage(
            "This request is no longer approved. Refresh the page.",
            "error"
        );
        return;
    }

    if (!["RECEIVED", "PARTIAL"].includes(getDonationStatus(donation))) {
        showFormMessage(
            "This donation is not available for distribution.",
            "error"
        );
        return;
    }

    if (!isDonationMatchingRequest(donation, request)) {
        showFormMessage(
            "The selected donation does not match the request's category and size.",
            "error"
        );
        return;
    }

    const requestRemaining = getRemainingRequestQuantity(request);
    const donationRemaining = getRemainingDonationQuantity(donation);
    const maximum = Math.min(requestRemaining, donationRemaining);

    if (!Number.isInteger(quantity) || quantity < 1) {
        showFormMessage(
            "Enter a valid whole-number quantity greater than zero.",
            "error"
        );
        return;
    }

    if (quantity > maximum) {
        showFormMessage(
            `The quantity cannot exceed ${maximum}. Check the remaining request and donation quantities.`,
            "error"
        );
        return;
    }

    const button = document.getElementById("recordDistributionBtn");

    if (!button) {
        showFormMessage(
            "The Record Distribution button could not be found.",
            "error"
        );
        return;
    }

    button.disabled = true;
    button.textContent = "Recording...";

    showFormMessage("Recording the distribution...");

    try {
        const response = await fetch(
            `${DISTRIBUTIONS_API}/api/distributions`,
            {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${token}`
                },
                body: JSON.stringify({
                    requestId: Number(requestId),
                    donationId: Number(donationId),
                    quantity,
                    comments: comments || null
                })
            }
        );

        const result = await response.json().catch(() => ({}));

        if (response.status === 401) {
            logout();
            throw new Error("Your session has expired. Please log in again.");
        }

        if (!response.ok || result.success === false) {
            throw new Error(
                result.message || "Unable to record the distribution."
            );
        }

        const form = document.getElementById("distributionForm");
        if (form) form.reset();

        showFormMessage(
            result.message || "Distribution recorded successfully.",
            "success"
        );

        await loadPageData();
    } catch (error) {
        console.error("Record distribution error:", error);

        showFormMessage(
            error.message || "Unable to record the distribution.",
            "error"
        );
    } finally {
        button.disabled = false;
        button.textContent = "Record Distribution";
    }
}

/* =========================================
   DASHBOARD SUMMARY
========================================= */

function updateDistributionSummary() {
    updateDashboardStats();
}

function updateDashboardStats() {
    const completed = allDistributions.filter(
        isCompletedDistribution
    );

    const pending = allDistributions.filter(record =>
        getDistributionStatus(record) === "PENDING"
    );

    const totalQuantity = completed.reduce((total, record) => {
        const quantity =
            Number(getValue(record, "QUANTITY", "quantity")) || 0;

        return total + quantity;
    }, 0);

    const setStat = (ids, value) => {
        ids.forEach(id => {
            const element = document.getElementById(id);
            if (element) element.textContent = String(value);
        });
    };

    setStat(["totalCount"], allDistributions.length);
    setStat(
        ["distributedQuantity", "itemsDistributed", "quantityCount"],
        totalQuantity
    );
    setStat(
        ["completedCount", "completedDistributionCount"],
        completed.length
    );
    setStat(
        ["pendingCount", "pendingDistributionCount"],
        pending.length
    );
}

/* =========================================
   DISTRIBUTION TABLE
========================================= */

function renderDistributions() {
    const tbody = document.getElementById("distributionsTableBody");
    if (!tbody) return;

    const searchInput = document.getElementById("searchInput");
    const statusFilter = document.getElementById("statusFilter");

    const search = searchInput
        ? searchInput.value.trim().toLowerCase()
        : "";

    const selectedStatus = statusFilter ? statusFilter.value : "";

    const filtered = allDistributions.filter(record => {
        const id = getValue(record, "DISTRIBUTIONID", "DISTRIBUTION_ID");
        const requestId = getValue(record, "REQUESTID", "REQUEST_ID");
        const donationId = getValue(record, "DONATIONID", "DONATION_ID");
        const learner = getLearnerDisplay(record);
        const status = getDistributionStatus(record);

        const searchableText =
            `${id} ${requestId} ${donationId} ${learner}`.toLowerCase();

        return (
            searchableText.includes(search) &&
            (!selectedStatus || status === selectedStatus)
        );
    });

    if (filtered.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="8" class="empty-state">
                    No distribution records match your search.
                </td>
            </tr>`;
        return;
    }

    tbody.innerHTML = filtered.map(record => {
        const id = getValue(
            record,
            "DISTRIBUTIONID",
            "DISTRIBUTION_ID"
        ) || "—";

        const requestId = getValue(
            record,
            "REQUESTID",
            "REQUEST_ID"
        ) || "—";

        const donationId = getValue(
            record,
            "DONATIONID",
            "DONATION_ID"
        ) || "—";

        const learner = getLearnerDisplay(record);

        const quantity = getValue(
            record,
            "QUANTITY",
            "quantity"
        ) || "—";

        const date = formatDistributionDate(
            getValue(
                record,
                "DISTRIBUTIONDATE",
                "DISTRIBUTION_DATE",
                "DATE_DISTRIBUTED",
                "CREATED_AT"
            )
        );

        const status = getDistributionStatus(record);
        const statusClass = status.toLowerCase();

        const comments = getValue(
            record,
            "COMMENTS",
            "COMMENT",
            "DISTRIBUTIONNOTE",
            "DISTRIBUTION_NOTE",
            "NOTES"
        ) || "—";

        return `
            <tr>
                <td>${escapeHTML(id)}</td>
                <td>${escapeHTML(requestId)}</td>
                <td>${escapeHTML(donationId)}</td>
                <td>${escapeHTML(learner)}</td>
                <td>${escapeHTML(quantity)}</td>
                <td>${escapeHTML(date)}</td>
                <td>
                    <span class="distribution-status ${escapeHTML(statusClass)}">
                        ${escapeHTML(status)}
                    </span>
                </td>
                <td>${escapeHTML(comments)}</td>
            </tr>`;
    }).join("");
}

function getLearnerDisplay(record) {
    const learnerName = getValue(
        record,
        "LEARNER_NAME",
        "FULL_NAME",
        "PERSON_NAME",
        "STUDENT_NAME"
    );

    if (learnerName) return learnerName;

    const learnerId = getValue(
        record,
        "CURRENTID",
        "LEARNERID",
        "LEARNER_ID"
    );

    return learnerId ? `Learner ID ${learnerId}` : "—";
}

function formatDistributionDate(value) {
    if (!value) return "—";

    const text = String(value);
    const dateOnly = text.match(/^(\d{4}-\d{2}-\d{2})/);

    if (dateOnly) {
        const [year, month, day] = dateOnly[1].split("-");
        return `${day}/${month}/${year}`;
    }

    const date = new Date(value);

    if (Number.isNaN(date.getTime())) {
        return text;
    }

    return date.toLocaleDateString("en-ZA");
}

function escapeHTML(value) {
    return String(value ?? "").replace(/[&<>"']/g, character => ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#39;"
    })[character]);
}
