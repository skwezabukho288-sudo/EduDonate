
const REQUESTS_API = "http://localhost:3000";

let allRequests = [];

document.addEventListener("DOMContentLoaded", () => {
    document.getElementById("searchInput")
        .addEventListener("input", renderRequests);

    document.getElementById("statusFilter")
        .addEventListener("change", renderRequests);

    document.getElementById("refreshBtn")
        .addEventListener("click", loadRequests);
    
    document.getElementById("requestsTableBody")
    .addEventListener("click", handleRequestAction);

    document.getElementById("logoutBtn")
        .addEventListener("click", logout);

    const menuButton = document.getElementById("dashboardMenuButton");
    const sidebar = document.getElementById("dashboardSidebar");

    menuButton.addEventListener("click", () => {
        const isOpen = sidebar.classList.toggle("open");
        menuButton.setAttribute("aria-expanded", String(isOpen));
    });

    loadRequests();
});

function getToken() {
    return sessionStorage.getItem("edudonate_token") ||
        localStorage.getItem("edudonate_token");
}

function getStoredUser() {
    const stored = sessionStorage.getItem("edudonate_user") ||
        localStorage.getItem("edudonate_user");

    try {
        return stored ? JSON.parse(stored) : null;
    } catch {
        return null;
    }
}

function logout() {
    sessionStorage.removeItem("edudonate_token");
    sessionStorage.removeItem("edudonate_user");
    localStorage.removeItem("edudonate_token");
    localStorage.removeItem("edudonate_user");

    window.location.href = "../login.html";
}

async function loadRequests() {
    const message = document.getElementById("pageMessage");
    const tbody = document.getElementById("requestsTableBody");
    const token = getToken();

    if (!token) {
        window.location.href = "../login.html";
        return;
    }

    message.textContent = "Loading learner requests...";
    message.classList.add("show");

    tbody.innerHTML = `
        <tr>
            <td colspan="6" class="empty-state">Loading requests...</td>
        </tr>`;

    try {
        const response = await fetch(`${REQUESTS_API}/api/requests`, {
            headers: {
                Authorization: `Bearer ${token}`
            }
        });

        const result = await response.json();

        if (response.status === 401) {
            logout();
            return;
        }

        if (!response.ok || result.success === false) {
            throw new Error(result.message || "Unable to load learner requests.");
        }

        const user = getStoredUser();

        if (user && String(user.role || "").toUpperCase() !== "COORDINATOR") {
            throw new Error("This page is only available to Donation Coordinators.");
        }

        document.getElementById("coordinatorName").textContent =
            user?.firstName ||
            user?.firstname ||
            user?.FIRSTNAME ||
            user?.username ||
            "Donation Coordinator";

        allRequests = Array.isArray(result.requests)
            ? result.requests
            : [];

        updateSummary();
        renderRequests();

        message.textContent =
            `Loaded ${allRequests.length} learner request(s) for your school.`;

    } catch (error) {
        console.error("Load learner requests error:", error);

        message.textContent =
            error.message || "Unable to load learner requests.";

        tbody.innerHTML = `
            <tr>
                <td colspan="6" class="empty-state">
                    Could not load requests. Check the server and try Refresh.
                </td>
            </tr>`;

        ["totalCount", "pendingCount", "approvedCount", "collectedCount"]
            .forEach(id => {
                document.getElementById(id).textContent = "—";
            });
    }
}

function getValue(record, ...keys) {
    for (const key of keys) {
        if (record[key] !== undefined && record[key] !== null) {
            return record[key];
        }
    }

    return "";
}

function getStatus(request) {
    return String(getValue(
        request,
        "STATUS",
        "REQUEST_STATUS",
        "status"
    ) || "UNKNOWN").toUpperCase();
}

function getItemName(request) {
    return getValue(
        request,
        "UNIFORM_TYPE",
        "STATIONARY_TYPE",
        "ITEM_NAME",
        "ITEM_CATEGORY",
        "CATEGORY_NAME"
    ) || "Item details unavailable";
}

function getLearnerName(request) {
    const directName = getValue(
        request,
        "LEARNER_NAME",
        "FULL_NAME",
        "PERSON_NAME",
        "LEARNER",
        "STUDENT_NAME"
    );

    if (directName) return directName;

    const firstName = getValue(
        request,
        "FIRSTNAME",
        "FIRST_NAME",
        "FNAME"
    );

    const surname = getValue(
        request,
        "SURNAME",
        "LASTNAME",
        "LAST_NAME"
    );

    return [firstName, surname].filter(Boolean).join(" ") || "Learner";
}

function updateSummary() {
    document.getElementById("totalCount").textContent =
        allRequests.length;

    document.getElementById("pendingCount").textContent =
        allRequests.filter(request => getStatus(request) === "PENDING").length;

    document.getElementById("approvedCount").textContent =
        allRequests.filter(request => getStatus(request) === "APPROVED").length;

    document.getElementById("collectedCount").textContent =
        allRequests.filter(request => getStatus(request) === "COLLECTED").length;
}

function renderRequests() {
    const tbody = document.getElementById("requestsTableBody");
    const search = document.getElementById("searchInput")
        .value.trim().toLowerCase();

    const selectedStatus = document.getElementById("statusFilter").value;

    const filtered = allRequests.filter(request => {
        const learner = getLearnerName(request);
        const item = getItemName(request);
        const id = getValue(request, "REQUESTID", "REQUEST_ID", "REQUESTID");
        const status = getStatus(request);

        const matchesSearch =
            `${learner} ${item} ${id}`.toLowerCase().includes(search);

        const matchesStatus =
            !selectedStatus || status === selectedStatus;

        return matchesSearch && matchesStatus;
    });

    if (filtered.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="6" class="empty-state">
                    No learner requests match your search.
                </td>
            </tr>`;
        return;
    }

    tbody.innerHTML = filtered.map(request => {
        const id = getValue(
            request,
            "REQUESTID",
            "REQUEST_ID",
            "ID",
            "id"
        );
        const learner = getLearnerName(request);
        const item = getItemName(request);
        const quantity = getValue(
            request,
            "QUANTITY",
            "ITEM_QUANTITY",
            "QTY",
            "quantity"
        ) || "—";
        const date = formatRequestDate(getValue(
    request,
    "REQUESTDATE",
    "REQUEST_DATE",
    "DATE_CREATED",
    "CREATED_AT",
    "DATE",
    "date"
));
        const status = getStatus(request);
        const statusClass = status.toLowerCase();

        return `
    <tr>
        <td>${escapeHTML(id)}</td>
        <td><strong>${escapeHTML(learner)}</strong></td>
        <td>${escapeHTML(item)}</td>
        <td>${escapeHTML(quantity)}</td>
        <td>${escapeHTML(date)}</td>
        <td>
            <span class="request-status ${escapeHTML(statusClass)}">
                ${escapeHTML(status)}
            </span>
        </td>
        <td>
            ${
                status === "PENDING"
                    ? `
                        <div class="request-actions">
                            <button
                                type="button"
                                class="action-button approve-button"
                                data-request-id="${escapeHTML(id)}"
                                data-action="APPROVED"
                            >Approve</button>

                            <button
                                type="button"
                                class="action-button reject-button"
                                data-request-id="${escapeHTML(id)}"
                                data-action="REJECTED"
                            >Reject</button>
                        </div>
                    `
                    : "—"
            }
        </td>
    </tr>`;
    }).join("");
}

function formatRequestDate(value) {
    if (!value) return "—";

    const date = new Date(value);

    if (Number.isNaN(date.getTime())) {
        return String(value);
    }

    return date.toLocaleDateString();
}

function escapeHTML(value) {
    return String(value ?? "").replace(/[&<>"']/g, character => ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#39;"
    })[character]);
}

async function handleRequestAction(event) {
    const button = event.target.closest("button[data-action]");

    if (!button) return;

    const requestId = button.dataset.requestId;
    const newStatus = button.dataset.action;

    if (!["APPROVED", "REJECTED"].includes(newStatus)) {
        return;
    }

    const actionLabel = newStatus === "APPROVED"
        ? "approve"
        : "reject";

    const confirmed = window.confirm(
        `Are you sure you want to ${actionLabel} request #${requestId}?`
    );

    if (!confirmed) return;

    const token = getToken();
    if (!token) {
        window.location.href = "../login.html";
        return;
    }

    const message = document.getElementById("pageMessage");
    const buttons = document.querySelectorAll(
        `button[data-request-id="${requestId}"]`
    );

    buttons.forEach(item => {
        item.disabled = true;
    });

    message.textContent = `Updating request #${requestId}...`;
    message.classList.add("show");

    try {
        const response = await fetch(
            `${REQUESTS_API}/api/requests/${encodeURIComponent(requestId)}`,
            {
                method: "PUT",
                headers: {
                    "Authorization": `Bearer ${token}`,
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    status: newStatus
                })
            }
        );

        const result = await response.json();

        if (response.status === 401) {
            logout();
            return;
        }

        if (!response.ok || result.success === false) {
            throw new Error(
                result.message || "The request could not be updated."
            );
        }

        message.textContent = `Request #${requestId} was ${newStatus.toLowerCase()} successfully.`;

        await loadRequests();
    } catch (error) {
        console.error("Update request error:", error);
        message.textContent = error.message || "Unable to update the request.";

        buttons.forEach(item => {
            item.disabled = false;
        });
    }
}
;