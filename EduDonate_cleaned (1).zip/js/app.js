


 
document.addEventListener("DOMContentLoaded", () => {
    initializeMobileNavigation();
    initializeNavigationHighlight();
});

/** Mobile Navigation */
function initializeMobileNavigation() {
    const menuButton = document.getElementById("mobileMenuButton");
    const navigation = document.getElementById("mainNavigation");

    if (!menuButton || !navigation) return;

    menuButton.addEventListener("click", () => {
        const isOpen = navigation.classList.toggle("open");
        menuButton.setAttribute("aria-expanded", String(isOpen));
    });

    navigation.querySelectorAll("a").forEach((link) => {
        link.addEventListener("click", () => {
            navigation.classList.remove("open");
            menuButton.setAttribute("aria-expanded", "false");
        });
    });
}

/** Navigation Active State */
function initializeNavigationHighlight() {
    const sections = document.querySelectorAll("main section[id]");
    const navigationLinks = document.querySelectorAll(
        ".main-navigation .nav-link"
    );

    if (!sections.length || !navigationLinks.length) return;

    const updateActiveLink = () => {
        let currentSection = "";

        sections.forEach((section) => {
            if (window.scrollY >= section.offsetTop - 150) {
                currentSection = section.getAttribute("id");
            }
        });

        navigationLinks.forEach((link) => {
            link.classList.toggle(
                "active",
                link.getAttribute("href") === `#${currentSection}`
            );
        });
    };

    window.addEventListener("scroll", updateActiveLink);
    updateActiveLink();
}