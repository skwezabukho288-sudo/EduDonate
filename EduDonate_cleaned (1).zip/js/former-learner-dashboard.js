
const FORMER_LEARNER_API = "http://localhost:3000";

let formerLearnerDonations = [];

document.addEventListener("DOMContentLoaded", () => {
    const menuButton = document.getElementById("menuButton");
    const sidebar = document.getElementById("sidebar");
    const logoutButton = document.getElementById("logoutButton");

    menuButton.addEventListener("click", () => {
        const isOpen = sidebar.classList.toggle("open");
        menuButton.setAttribute("aria-expanded", String(isOpen));
    });

    logoutButton.addEventListener("click", logout);

    loadFormerLearnerDashboard();
});

function getToken() {
    return (
        sessionStorage.getItem("edudonate_token") ||
        localStorage.getItem("edudonate_token")
    );
}

function getStoredUser() {
    const stored =
        sessionStorage.getItem("edudonate_user") ||
        localStorage.getItem("edudonate_user");

    try {
        return stored ? JSON.parse(stored) : null;
    } catch (error) {
        console.error("Unable to read stored user:", error);
        return null;
    }
}

function logout() {
    sessionStorage.removeItem("edudonate_token");
    sessionStorage.removeItem("edudonate_user");

    localStorage.removeItem("edudonate_token");
    localStorage.removeItem("edudonate_user");

    window.location.href = "../login.html";
}

function getValue(record, ...keys) {
    for (const key of keys) {
        if (
            record &&
            record[key] !== undefined &&
            record[key] !== null
        ) {
            return record[key];
        }
    }

    return "";
}

function showMessage(message, type = "info") {
    const element = document.getElementById("pageMessage");

    element.textContent = message;
    element.className = `message show ${type}`;
}

function setUserDetails(user) {
    const firstName =
        user?.firstName ||
        user?.firstname ||
        user?.FIRSTNAME ||
        "";

    const lastName =
        user?.lastName ||
        user?.lastname ||
        user?.LASTNAME ||
        "";

    const fullName =
        user?.fullName ||
        user?.FULL_NAME ||
        [firstName, lastName].filter(Boolean).join(" ") ||
        user?.username ||
        user?.USERNAME ||
        "Former Learner";

    document.getElementById("userName").textContent = fullName;
    document.getElementById("welcomeName").textContent =
        firstName || fullName.split(" ")[0];

    const initials = fullName
        .trim()
        .split(/\s+/)
        .slice(0, 2)
        .map(part => part.charAt(0).toUpperCase())
        .join("");

    document.getElementById("userInitials").textContent =
        initials || "FL";
}

async function loadFormerLearnerDashboard() {
    const token = getToken();
    const user = getStoredUser();

    if (!token) {
        window.location.href = "../login.html";
        return;
    }

    if (
        user &&
        String(user.role || user.ROLE || "").toUpperCase() !==
            "FORMER_LEARNER"
    ) {
        showMessage(
            "This dashboard is for Former Learner accounts. Please sign in using a Former Learner account.",
            "error"
        );
        return;
    }

    setUserDetails(user);

    showMessage("Loading your donation information...");

    try {
        const response = await fetch(
            `${FORMER_LEARNER_API}/api/donations`,
            {
                method: "GET",
                headers: {
                    Authorization: `Bearer ${token}`
                }
            }
        );

        const result = await response.json().catch(() => ({}));

        if (response.status === 401) {
            logout();
            return;
        }

        if (!response.ok || result.success === false) {
            throw new Error(
                result.message ||
                "Unable to load your donation information."
            );
        }

        formerLearnerDonations = Array.isArray(result.donations)
            ? result.donations
            : [];

        updateDonationStatistics();
        renderRecentDonations();

        showMessage(
            "Your donation information has been loaded successfully.",
            "success"
        );

    } catch (error) {
        console.error("Former Learner dashboard error:", error);

        showMessage(
            error.message ||
            "Unable to load your donations. Please try again.",
            "error"
        );

        ["donationCount", "itemCount", "pendingCount", "schoolCount"]
            .forEach(id => {
                document.getElementById(id).textContent = "—";
            });

        document.getElementById("recentDonationsBody").innerHTML = `
            <tr>
                <td colspan="5" class="empty-state">
                    Could not load donations. Check the server and try again.
                </td>
            </tr>`;
    }
}

function getDonationStatus(donation) {
    return String(
        getValue(
            donation,
            "CONFIRMATION",
            "STATUS",
            "DONATION_STATUS",
            "status"
        ) || "UNKNOWN"
    ).trim().toUpperCase();
}

function getDonationQuantity(donation) {
    return Number(
        getValue(
            donation,
            "QUANTITY",
            "ITEM_QUANTITY",
            "QTY",
            "quantity"
        )
    ) || 0;
}

function updateDonationStatistics() {
    const pendingStatuses = [
        "PENDING",
        "SUBMITTED",
        "PENDING_CONFIRMATION",
        "AWAITING_CONFIRMATION"
    ];

    const totalItems = formerLearnerDonations.reduce(
        (total, donation) => total + getDonationQuantity(donation),
        0
    );

    const pendingCount = formerLearnerDonations.filter(donation =>
        pendingStatuses.includes(getDonationStatus(donation))
    ).length;

    const supportedSchools = new Set();

    formerLearnerDonations.forEach(donation => {
        const schoolName = String(
            getValue(
                donation,
                "SCHOOLNAME",
                "SCHOOL_NAME",
                "SCHOOL"
            ) || ""
        ).trim();

        const schoolId = getValue(
            donation,
            "SCHOOLID",
            "SCHOOL_ID"
        );

        if (schoolName) {
            supportedSchools.add(schoolName.toLowerCase());
        } else if (schoolId !== "") {
            supportedSchools.add(String(schoolId));
        }
    });

    document.getElementById("donationCount").textContent =
        formerLearnerDonations.length;

    document.getElementById("itemCount").textContent =
        totalItems;

    document.getElementById("pendingCount").textContent =
        pendingCount;

    document.getElementById("schoolCount").textContent =
        supportedSchools.size;
}

function getDonationItem(donation) {
    return getValue(
        donation,
        "ITEM_NAME",
        "ITEMNAME",
        "UNIFORM_TYPE",
        "STATIONARY_TYPE",
        "STATIONERY_TYPE",
        "ITEM_TYPE",
        "PRODUCT_NAME"
    ) || "Item details unavailable";
}

function getDonationDate(donation) {
    return getValue(
        donation,
        "DONATIONDATE",
        "DONATION_DATE",
        "DATE_CREATED",
        "CREATED_AT",
        "DATE"
    );
}

function formatDonationDate(value) {
    if (!value) return "—";

    const date = new Date(value);

    if (Number.isNaN(date.getTime())) {
        return String(value);
    }

    return date.toLocaleDateString("en-ZA");
}

function renderRecentDonations() {
    const tbody = document.getElementById("recentDonationsBody");

    const recentDonations = [...formerLearnerDonations]
        .sort((a, b) => {
            const dateA = new Date(getDonationDate(a) || 0).getTime();
            const dateB = new Date(getDonationDate(b) || 0).getTime();

            return dateB - dateA;
        })
        .slice(0, 5);

    if (recentDonations.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="5" class="empty-state">
                    You have not made any donations yet.
                    Use "Make a Donation" to get started.
                </td>
            </tr>`;
        return;
    }

    tbody.innerHTML = recentDonations.map(donation => {
        const date = formatDonationDate(getDonationDate(donation));

        const item = getDonationItem(donation);

        const quantity = getDonationQuantity(donation);

        const school = getValue(
            donation,
            "SCHOOLNAME",
            "SCHOOL_NAME",
            "SCHOOL"
        ) || "—";

        const status = getDonationStatus(donation);

        const statusClass = [
            "received",
            "completed",
            "pending",
            "partial"
        ].includes(status.toLowerCase())
            ? status.toLowerCase()
            : "";

        return `
            <tr>
                <td>${escapeHTML(date)}</td>
                <td>${escapeHTML(item)}</td>
                <td>${escapeHTML(quantity)}</td>
                <td>${escapeHTML(school)}</td>
                <td>
                    <span class="status-badge ${escapeHTML(statusClass)}">
                        ${escapeHTML(status)}
                    </span>
                </td>
            </tr>`;
    }).join("");
}

function escapeHTML(value) {
    return String(value ?? "").replace(/[&<>"']/g, character => ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#39;"
    })[character]);
}
