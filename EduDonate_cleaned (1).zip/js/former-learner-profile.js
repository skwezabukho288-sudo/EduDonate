
"use strict";

const FORMER_LEARNER_API = "http://localhost:3000";

/* =========================================
   INITIALIZE PROFILE PAGE
========================================= */

document.addEventListener("DOMContentLoaded", () => {
    const menuButton = document.getElementById("menuButton");
    const logoutButton = document.getElementById("logoutButton");

    if (menuButton) {
        menuButton.addEventListener("click", toggleMenu);
    }

    if (logoutButton) {
        logoutButton.addEventListener("click", logout);
    }

    loadFormerLearnerProfile();
});

/* =========================================
   AUTHENTICATION
========================================= */

function getToken() {
    return (
        sessionStorage.getItem("edudonate_token") ||
        localStorage.getItem("edudonate_token")
    );
}

function getStoredUser() {
    const stored =
        sessionStorage.getItem("edudonate_user") ||
        localStorage.getItem("edudonate_user");

    try {
        return stored ? JSON.parse(stored) : null;
    } catch (error) {
        console.error("Unable to read stored user:", error);
        return null;
    }
}

function logout() {
    sessionStorage.removeItem("edudonate_token");
    sessionStorage.removeItem("edudonate_user");

    localStorage.removeItem("edudonate_token");
    localStorage.removeItem("edudonate_user");

    window.location.href = "/pages/login.html";
}

/* =========================================
   MOBILE MENU
========================================= */

function toggleMenu() {
    const sidebar = document.getElementById("sidebar");
    const button = document.getElementById("menuButton");

    if (!sidebar) {
        return;
    }

    const isOpen = sidebar.classList.toggle("open");

    if (button) {
        button.setAttribute("aria-expanded", String(isOpen));
    }
}

/* =========================================
   GENERAL HELPERS
========================================= */

function getValue(record, ...keys) {
    for (const key of keys) {
        if (
            record &&
            record[key] !== undefined &&
            record[key] !== null
        ) {
            return record[key];
        }
    }

    return "";
}

function displayValue(value, fallback = "—") {
    if (
        value === "" ||
        value === null ||
        value === undefined
    ) {
        return fallback;
    }

    return String(value);
}

function setText(id, value, fallback = "—") {
    const element = document.getElementById(id);

    if (element) {
        element.textContent = displayValue(value, fallback);
    }
}

function showMessage(message, type = "info") {
    const element = document.getElementById("pageMessage");

    if (!element) {
        console.info(message);
        return;
    }

    element.textContent = message;
    element.className = `message show ${type}`;
}

/* =========================================
   DATE FORMATTING
========================================= */

function formatDate(value) {
    if (value === null || value === undefined || value === "") {
        return "";
    }

    const text = String(value);

    // Preserve date-only values without timezone changes.
    const dateOnly = text.match(/^(\d{4})-(\d{2})-(\d{2})/);

    if (dateOnly) {
        const [, year, month, day] = dateOnly;
        return `${day}/${month}/${year}`;
    }

    const date = new Date(value);

    if (Number.isNaN(date.getTime())) {
        return text;
    }

    return date.toLocaleDateString("en-ZA");
}

/* =========================================
   DISPLAY PROFILE INFORMATION
========================================= */

function populateProfile(profile) {
    if (!profile) {
        showMessage("No profile information was returned.", "error");
        return;
    }

    const firstName = getValue(
        profile,
        "FIRSTNAME",
        "firstName"
    );

    const lastName = getValue(
        profile,
        "LASTNAME",
        "lastName"
    );

    const username = getValue(
        profile,
        "USERNAME",
        "username"
    );

    const fullName =
        [
            firstName,
            lastName
        ].filter(Boolean).join(" ") ||
        username ||
        "Former Learner";

    const initials = fullName
        .trim()
        .split(/\s+/)
        .slice(0, 2)
        .map(part => part.charAt(0).toUpperCase())
        .join("") || "FL";

    // Profile banner and sidebar.
    setText("profileFullName", fullName, "Former Learner");
    setText("profileUsername", `Username: ${username || "—"}`);
    setText("userInitials", initials, "FL");
    setText("userName", fullName, "Former Learner");

    // Personal information.
    setText("firstName", firstName);
    setText("lastName", lastName);

    setText(
        "email",
        getValue(profile, "EMAIL", "email")
    );

    setText(
        "phone",
        getValue(profile, "PHONENO", "PHONE", "phone")
    );

    setText(
        "gender",
        getValue(profile, "GENDER", "gender")
    );

    setText("username", username);

    setText(
        "personId",
        getValue(profile, "PERSONID", "personId")
    );

    // Learner information.
    setText(
        "learnerId",
        getValue(profile, "LEARNERID", "learnerId")
    );

    setText(
        "formerId",
        getValue(profile, "FORMERID", "formerId")
    );

    setText(
        "grade",
        getValue(profile, "GRADE", "grade"),
        "Not provided"
    );

    setText(
        "leaveGrade",
        getValue(profile, "LEAVEGRADE", "leaveGrade"),
        "Not provided"
    );

    const leaveDate = getValue(
        profile,
        "LEAVEDATE",
        "leaveDate"
    );

    setText(
        "leaveDate",
        formatDate(leaveDate),
        "Not provided"
    );

    // School and location information.
    setText(
        "schoolName",
        getValue(profile, "SCHOOLNAME", "schoolName")
    );

    setText(
        "schoolId",
        getValue(profile, "SCHOOLID", "schoolId")
    );

    setText(
        "schoolEmis",
        getValue(
            profile,
            "SCHOOL_EMIS",
            "SCHOOL_EMIS_NO",
            "schoolEmis"
        )
    );

    setText(
        "locationName",
        getValue(
            profile,
            "LOCNAME",
            "LOCATION_NAME",
            "locationName"
        )
    );

    setText(
        "townName",
        getValue(
            profile,
            "TOWNNAME",
            "TOWN_NAME",
            "townName"
        )
    );
}

/* =========================================
   LOAD FORMER LEARNER PROFILE
========================================= */

async function loadFormerLearnerProfile() {
    const token = getToken();
    const user = getStoredUser();

    if (!token) {
        window.location.href = "/pages/login.html";
        return;
    }

    const role = String(
        getValue(user, "role", "ROLE")
    ).trim().toUpperCase();

    if (user && role !== "FORMER_LEARNER") {
        showMessage(
            "This page is only available to Former Learner accounts.",
            "error"
        );
        return;
    }

    showMessage("Loading your profile...");

    try {
        const response = await fetch(
            `${FORMER_LEARNER_API}/api/donations/profile`,
            {
                method: "GET",
                headers: {
                    Authorization: `Bearer ${token}`,
                    Accept: "application/json"
                }
            }
        );

        const result = await response.json().catch(() => ({}));

        if (response.status === 401) {
            logout();
            return;
        }

        if (response.status === 403) {
            showMessage(
                result.message ||
                    "You do not have permission to view this profile.",
                "error"
            );
            return;
        }

        if (!response.ok || result.success === false) {
            throw new Error(
                result.message ||
                    `Unable to load your profile (HTTP ${response.status}).`
            );
        }

        // Support either { profile: {...} } or { user: {...} }.
        const profile = result.profile || result.user;

        if (!profile) {
            throw new Error(
                "The server did not return your profile information."
            );
        }

        populateProfile(profile);

        showMessage(
            "Your profile has been loaded successfully.",
            "success"
        );

    } catch (error) {
        console.error("Former Learner profile error:", error);

        showMessage(
            error.message ||
                "Unable to load your profile. Please try again.",
            "error"
        );
    }
}
