
"use strict";

const FORMER_LEARNER_API = "http://localhost:3000";

/* =========================================
   INITIALIZE DONATION PAGE
========================================= */

document.addEventListener("DOMContentLoaded", () => {
    const menuButton = document.getElementById("menuButton");
    const sidebar = document.getElementById("sidebar");
    const logoutButton = document.getElementById("logoutButton");
    const donationForm = document.getElementById("donationForm");

    if (menuButton && sidebar) {
        menuButton.addEventListener("click", () => {
            const isOpen = sidebar.classList.toggle("open");
            menuButton.setAttribute("aria-expanded", String(isOpen));
        });
    }

    if (logoutButton) {
        logoutButton.addEventListener("click", logout);
    }

    if (donationForm) {
        donationForm.addEventListener("submit", submitDonation);
    }

    setTodayAsDefault();
    loadDonationOptions();
});

/* =========================================
   AUTHENTICATION HELPERS
========================================= */

function getToken() {
    return (
        sessionStorage.getItem("edudonate_token") ||
        localStorage.getItem("edudonate_token")
    );
}

function getStoredUser() {
    const stored =
        sessionStorage.getItem("edudonate_user") ||
        localStorage.getItem("edudonate_user");

    try {
        return stored ? JSON.parse(stored) : null;
    } catch (error) {
        console.error("Unable to read stored user:", error);
        return null;
    }
}

function logout() {
    sessionStorage.removeItem("edudonate_token");
    sessionStorage.removeItem("edudonate_user");

    localStorage.removeItem("edudonate_token");
    localStorage.removeItem("edudonate_user");

    window.location.href = "/pages/login.html";
}

/* =========================================
   GENERAL HELPERS
========================================= */

function getValue(record, ...keys) {
    for (const key of keys) {
        if (
            record &&
            record[key] !== undefined &&
            record[key] !== null
        ) {
            return record[key];
        }
    }

    return "";
}

function showFormMessage(message, type = "info") {
    const element = document.getElementById("formMessage");

    if (!element) {
        console.info(message);
        return;
    }

    element.textContent = message;
    element.className = `form-message show ${type}`;
}

/* =========================================
   DEFAULT DONATION DATE
========================================= */

function setTodayAsDefault() {
    const dateInput = document.getElementById("donationDate");

    if (!dateInput) {
        return;
    }

    // Use the browser's local date instead of UTC.
    const now = new Date();
    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, "0");
    const day = String(now.getDate()).padStart(2, "0");

    dateInput.value = `${year}-${month}-${day}`;
}

/* =========================================
   DISPLAY USER DETAILS
========================================= */

function setUserDetails(user) {
    if (!user) {
        return;
    }

    const firstName = getValue(
        user,
        "firstName",
        "firstname",
        "FIRSTNAME"
    );

    const lastName = getValue(
        user,
        "lastName",
        "lastname",
        "LASTNAME"
    );

    const fullName =
        getValue(user, "fullName", "FULL_NAME") ||
        [firstName, lastName].filter(Boolean).join(" ") ||
        getValue(user, "username", "USERNAME") ||
        "Former Learner";

    const userName = document.getElementById("userName");
    const initialsElement = document.getElementById("userInitials");

    if (userName) {
        userName.textContent = fullName;
    }

    if (initialsElement) {
        initialsElement.textContent = fullName
            .trim()
            .split(/\s+/)
            .slice(0, 2)
            .map(part => part.charAt(0).toUpperCase())
            .join("") || "FL";
    }
}

/* =========================================
   LOAD DONATION CATEGORIES AND SIZES
   GET /api/donations/options
========================================= */

async function loadDonationOptions() {
    const token = getToken();
    const user = getStoredUser();

    if (!token) {
        window.location.href = "/pages/login.html";
        return;
    }

    const role = String(
        getValue(user, "role", "ROLE")
    ).trim().toUpperCase();

    if (user && role !== "FORMER_LEARNER") {
        showFormMessage(
            "This page is only available to Former Learner accounts.",
            "error"
        );
        return;
    }

    setUserDetails(user);

    const categorySelect = document.getElementById("categoryId");
    const sizeSelect = document.getElementById("sizeId");

    if (!categorySelect || !sizeSelect) {
        showFormMessage(
            "The category or size dropdown could not be found. Please check the donation page HTML.",
            "error"
        );
        return;
    }

    categorySelect.disabled = true;
    sizeSelect.disabled = true;

    categorySelect.innerHTML =
        '<option value="">Loading categories...</option>';

    sizeSelect.innerHTML =
        '<option value="">Loading sizes...</option>';

    showFormMessage("Loading donation categories and sizes...");

    try {
        const response = await fetch(
            `${FORMER_LEARNER_API}/api/donations/options`,
            {
                method: "GET",
                headers: {
                    Authorization: `Bearer ${token}`
                }
            }
        );

        const result = await response.json().catch(() => ({}));

        if (response.status === 401) {
            logout();
            return;
        }

        if (!response.ok || result.success === false) {
            throw new Error(
                result.message ||
                `Unable to load donation options (HTTP ${response.status}).`
            );
        }

        const categories = Array.isArray(result.categories)
            ? result.categories
            : [];

        const sizes = Array.isArray(result.sizes)
            ? result.sizes
            : [];

        populateCategories(categories);
        populateSizes(sizes);

        if (categories.length === 0 || sizes.length === 0) {
            showFormMessage(
                "No categories or sizes were returned. Check the database lookup records and API response.",
                "error"
            );
            return;
        }

        categorySelect.disabled = false;
        sizeSelect.disabled = false;

        showFormMessage(
            "Donation categories and sizes loaded successfully.",
            "success"
        );

    } catch (error) {
        console.error("Load donation options error:", error);

        categorySelect.innerHTML =
            '<option value="">Unable to load categories</option>';

        sizeSelect.innerHTML =
            '<option value="">Unable to load sizes</option>';

        showFormMessage(
            error.message ||
            "Could not load donation options. Check the server and try again.",
            "error"
        );
    }
}

/* =========================================
   POPULATE CATEGORY DROPDOWN
========================================= */

function populateCategories(categories) {
    const select = document.getElementById("categoryId");

    if (!select) {
        return;
    }

    select.innerHTML =
        '<option value="">Select a category</option>';

    categories.forEach(category => {
        const id = getValue(
            category,
            "CAID",
            "caid",
            "categoryId",
            "CATEGORYID"
        );

        const itemName = getValue(
            category,
            "ITEM_NAME",
            "ITEMNAME",
            "itemName"
        );

        const categoryName = getValue(
            category,
            "ITEM_CATEGORY",
            "CATEGORY",
            "category"
        );

        if (id === "") {
            return;
        }

        const option = document.createElement("option");
        option.value = String(id);

        const label = [itemName, categoryName]
            .filter(Boolean)
            .join(" — ");

        option.textContent = label || `Category ${id}`;

        select.appendChild(option);
    });
}

/* =========================================
   POPULATE SIZE DROPDOWN
========================================= */

function populateSizes(sizes) {
    const select = document.getElementById("sizeId");

    if (!select) {
        return;
    }

    select.innerHTML =
        '<option value="">Select an item size</option>';

    sizes.forEach(size => {
        const id = getValue(
            size,
            "ITSID",
            "itsid",
            "sizeId",
            "SIZEID"
        );

        const name = getValue(
            size,
            "ITEMSIZE",
            "itemSize",
            "SIZE_NAME",
            "SIZENAME"
        );

        if (id === "") {
            return;
        }

        const option = document.createElement("option");
        option.value = String(id);
        option.textContent = name || `Size ${id}`;

        select.appendChild(option);
    });
}

/* =========================================
   SUBMIT DONATION
   POST /api/donations
========================================= */

async function submitDonation(event) {
    event.preventDefault();

    const form = document.getElementById("donationForm");

    if (!form) {
        return;
    }

    const submitButton =
        document.getElementById("submitDonationButton") ||
        form.querySelector('button[type="submit"]');

    const token = getToken();

    if (!token) {
        window.location.href = "/pages/login.html";
        return;
    }

    if (!form.reportValidity()) {
        return;
    }

    const categoryElement = document.getElementById("categoryId");
    const sizeElement = document.getElementById("sizeId");
    const conditionElement = document.getElementById("condition");
    const quantityElement = document.getElementById("quantity");
    const donationDateElement = document.getElementById("donationDate");

    if (
        !categoryElement ||
        !sizeElement ||
        !conditionElement ||
        !quantityElement ||
        !donationDateElement
    ) {
        showFormMessage(
            "One or more required donation fields are missing from the page.",
            "error"
        );
        return;
    }

    const categoryId = Number(categoryElement.value);
    const sizeId = Number(sizeElement.value);
    const condition = conditionElement.value;
    const quantity = Number(quantityElement.value);
    const donationDate = donationDateElement.value;

    if (
        !Number.isInteger(categoryId) ||
        categoryId <= 0 ||
        !Number.isInteger(sizeId) ||
        sizeId <= 0
    ) {
        showFormMessage(
            "Please select a valid item category and size.",
            "error"
        );
        return;
    }

    if (!Number.isInteger(quantity) || quantity <= 0) {
        showFormMessage(
            "Quantity must be a whole number greater than zero.",
            "error"
        );
        return;
    }

    if (!condition || !donationDate) {
        showFormMessage(
            "Please complete all required fields.",
            "error"
        );
        return;
    }

    const payload = {
        categoryId,
        sizeId,
        condition,
        quantity,
        donationDate
    };

    if (submitButton) {
        submitButton.disabled = true;
        submitButton.textContent = "Submitting...";
    }

    showFormMessage("Submitting your donation...");

    try {
        const response = await fetch(
            `${FORMER_LEARNER_API}/api/donations`,
            {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${token}`
                },
                body: JSON.stringify(payload)
            }
        );

        const result = await response.json().catch(() => ({}));

        if (response.status === 401) {
            logout();
            return;
        }

        if (!response.ok || result.success === false) {
            throw new Error(
                result.message ||
                `Unable to submit your donation (HTTP ${response.status}).`
            );
        }

        form.reset();
        setTodayAsDefault();

        showFormMessage(
            result.message ||
            "Donation submitted successfully. It is now awaiting confirmation.",
            "success"
        );

    } catch (error) {
        console.error("Submit donation error:", error);

        showFormMessage(
            error.message ||
            "An error occurred while submitting your donation.",
            "error"
        );

    } finally {
        if (submitButton) {
            submitButton.disabled = false;
            submitButton.textContent = "Submit Donation";
        }
    }
}
