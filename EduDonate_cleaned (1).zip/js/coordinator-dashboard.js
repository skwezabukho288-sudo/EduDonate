const API_BASE_URL = "http://localhost:3000";

document.addEventListener("DOMContentLoaded", () => {
    initializeCoordinatorDashboard();
    initializeLogout();
});

function getAuthToken() {
    return (
        sessionStorage.getItem("edudonate_token") ||
        localStorage.getItem("edudonate_token")
    );
}

function getStoredUser() {
    const storedUser =
        sessionStorage.getItem("edudonate_user") ||
        localStorage.getItem("edudonate_user");

    try {
        return storedUser ? JSON.parse(storedUser) : null;
    } catch (error) {
        return null;
    }
}

async function apiRequest(endpoint) {
    const token = getAuthToken();

    if (!token) {
        window.location.href = "../login.html";
        throw new Error("Please sign in again.");
    }

    const response = await fetch(`${API_BASE_URL}${endpoint}`, {
        headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json"
        }
    });

    const result = await response.json();

    if (response.status === 401) {
        logout();
        throw new Error("Your session has expired. Please sign in again.");
    }

    if (!response.ok || result.success === false) {
        throw new Error(result.message || "Unable to load dashboard data.");
    }

    return result;
}

async function initializeCoordinatorDashboard() {
    const message = document.getElementById("pageMessage");

    if (!getAuthToken()) {
        window.location.href = "../login.html";
        return;
    }

    try {
        const profileResult = await apiRequest("/api/auth/me");
        const storedUser = getStoredUser();
        const user = profileResult.user || storedUser || profileResult;
        const role = String(user.role || "").toUpperCase();

        if (role !== "COORDINATOR") {
            message.textContent =
                "Access denied. Please sign in using a Donation Coordinator account.";
            return;
        }

        const displayName =
            user.firstName ||
            user.firstname ||
            user.FIRSTNAME ||
            user.username ||
            user.email ||
            "Donation Coordinator";

        document.getElementById("coordinatorName").textContent =
            `Welcome, ${displayName}`;

        const results = await Promise.allSettled([
            apiRequest("/api/donations"),
            apiRequest("/api/requests"),
            apiRequest("/api/distributions")
        ]);

        const donationResult = results[0];
        const requestResult = results[1];
        const distributionResult = results[2];

        const donations =
            donationResult.status === "fulfilled"
                ? donationResult.value.donations || []
                : [];

        const requests =
            requestResult.status === "fulfilled"
                ? requestResult.value.requests || []
                : [];

        const distributions =
            distributionResult.status === "fulfilled"
                ? distributionResult.value.distributions || []
                : [];

        const availableDonations = donations.filter(donation => {
            const quantity = Number(
                donation.QUANTITY ?? donation.quantity ?? 0
            );

            const status = String(
                donation.CONFIRMATION ||
                donation.STATUS ||
                donation.status ||
                ""
            ).toUpperCase();

            return quantity > 0 &&
                ["RECEIVED", "PARTIAL", "APPROVED"].includes(status);
        });

        const pendingRequests = requests.filter(request => {
            const status = String(
                request.STATUS ||
                request.REQUEST_STATUS ||
                request.status ||
                ""
            ).toUpperCase();

            return status === "PENDING";
        });

        document.getElementById("donationsCount").textContent =
            availableDonations.length;

        document.getElementById("requestsCount").textContent =
            requests.length;

        document.getElementById("pendingCount").textContent =
            pendingRequests.length;

        document.getElementById("distributionsCount").textContent =
            distributionResult.status === "fulfilled"
                ? distributions.length
                : "—";

        const failedSections = [];

        if (donationResult.status === "rejected") {
            failedSections.push("donations");
        }

        if (requestResult.status === "rejected") {
            failedSections.push("learner requests");
        }

        if (distributionResult.status === "rejected") {
            failedSections.push("distributions");
        }

        message.textContent = failedSections.length
            ? `Dashboard partly loaded. Could not load: ${failedSections.join(", ")}.`
            : "Dashboard connected successfully. Your school's data has loaded.";

    } catch (error) {
        console.error("Coordinator dashboard error:", error);
        message.textContent =
            error.message || "Unable to load your dashboard.";
    }
}

function initializeLogout() {
    const logoutButton = document.getElementById("logoutBtn");

    if (logoutButton) {
        logoutButton.addEventListener("click", logout);
    }
}

function logout() {
    sessionStorage.removeItem("edudonate_token");
    sessionStorage.removeItem("edudonate_user");
    localStorage.removeItem("edudonate_token");
    localStorage.removeItem("edudonate_user");

    window.location.href = "../login.html";
}